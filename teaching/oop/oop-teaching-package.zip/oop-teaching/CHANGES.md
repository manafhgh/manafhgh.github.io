# Important corrections and teaching decisions

- Expanded the reference swap into an explicit value/reference comparison.
- Added missing headers and main functions to incomplete snippets. Kept deliberately invalid calls commented so the supplied programs compile.
- Initialized pointers to `nullptr` and explained reference assignment without printing platform-specific addresses.
- Corrected the recursive array sum to call `sumArray_recursive`, rather than an unrelated `sum`. Corrected initializer comments and removed random data so output is reproducible. Explained that `sizeof` is an operator and array parameters do not preserve array size.
- Used const queries and const-reference parameters for Point; kept the original axis result of -1. The lifetime example uses separate value/reference calls to make copy construction easy to trace without relying on optional return-value copies.
- Supplied missing complete examples for interface/implementation separation, Line composition, and multiple/multilevel inheritance. Added the real three-file Point project.
- Unified Student GPA validation at 0–100, including constructor use. The source previously allowed default GPA 0 but setters required at least 35. This range is a teaching choice, not a statement of university grading policy.
- Initialized the temperature accumulator, rejected empty averages, validated scale labels, and corrected **temperature-difference** conversion: Fahrenheit-to-Celsius changes multiply by 5/9 without subtracting 32; Celsius-to-Fahrenheit changes multiply by 9/5 without adding 32. The original floating-point reading expressions did not themselves suffer integer division, because multiplication by a float occurred first.
- Made the Box count track live objects with a destructor. Its retained `modifyCount` method is explicitly labeled as a demonstration of access rules that breaks the counter's intended meaning; normal examples/exercises do not call it.
- Kept the primitive linked list as non-owning links to local objects. It does not pretend to be a general owning list or handle cycles.
- Removed executed memory leaks from the dynamic-memory example, initialized array elements, and paired every allocation with its matching deallocation. Explained why deleting a pointer to a local variable is invalid.
- Reworked the owning grade array to implement the Rule of Three: destructor, deep-copy constructor, and deep-copy assignment. Added input/index/range validation and a positive-size requirement. Introduced copy assignment here because safe ownership requires it, and noted the Rule of Zero alternative using `std::vector`.
- Fixed friend-function initialization comments and narrowed the friend-member example's parameter to a const reference.
- Showed both returned values and returned references in the `this` example.
- Corrected inheritance explanations: private base data remains in the base subobject. Removed an unused, undefined member declaration.
- Added virtual base destructors, explicit overrides, a proper Penguin constructor, and cleanup of the dynamically allocated Cat. Removed the blanket claim that direct virtual calls are necessarily statically bound: their concrete type can allow compiler devirtualization, but the language semantics remain virtual.
- Corrected the Circle downcast failure message and explained failed pointer casts versus failed reference casts. Distinguished pointer/reference upcasting from by-value object slicing.
- Removed the duplicate Student operator example. Made comparison queries const, equality return bool, and `+=` return the updated Student by reference. Explained exact floating-point equality limits.
- Implemented prefix/postfix increment conventions and made stream extraction leave the object unchanged if input fails.
- Added 24 understanding questions and 24 programming tasks, with complete compiled solutions. Exercise workspaces begin with a relevant working example, not an intentionally broken program. Solutions are hidden initially but publicly present in the static page source, which suits practice rather than graded assessment.


# Version 2: Revision and Classes and Objects

- Grouped the six introductory lessons under Revision while retaining their anchors; added console I/O and real text-file I/O with complete checked examples and exercises.
- Removed source-origin subtitles from every example title.
- Expanded Classes and Objects with prerequisites, learning objectives, class/object/state/interface explanations, constructor/default argument/const discussion, an accessible object-state stepper, output prediction feedback, guided experiments, a validated Student mini-project, staged hints, and a five-question checkpoint.
- Added six compiled code checks that accept the worked solution and reject the incomplete starter. Reviewed status and passed checkpoints are tracked separately. Editing a passed solution invalidates its code-check badge.
- Retained later course topics and their examples/exercises. Added standalone downloads for the new material.
- File examples use their own temporary working directory during local validation; online files are temporary and cannot access student computer files.


# Version 3: input/output display and memory

- Updated every standard-input placeholder to “Enter input before running if required”.
- Suppressed successful Exit code: 0 messages while keeping errors and runtime/service diagnostics.
- Added accessible, stepped SVG memory diagrams to Pointers and References and Dynamic Memory. Paired them with runnable trace programs and compiled state assertions.
- Moved the primitive linked-list topic into a collapsed optional exercise in Dynamic Memory, retaining its anchor and original runnable reference. Added a chain-building/traversal/insertion starter, hints, and full solution.
- Kept core progress separate from the optional exercise; core lessons now total 25 under 18 main topics.


# Version 4: focused navigation and complete guide structure

- Added the supplementary-material note immediately below the course title and removed the Read it / Predict it promotional paragraph.
- Changed navigation to one selected lesson with fragment links, Back/Forward, Previous/Next, a Revision overview, and optional View all.
- Expanded all 24 remaining core lessons with authored explanations, traces, experiments, predictions, staged hints, common mistakes, and three-question feedback checkpoints.
- Added disclosed sample-output checking to coding workspaces, distinct from full correctness checking.
- Converted all Point coordinate implementations to double and updated fractional examples, diagrams, and prediction answers.
- Extracted page-shell.html to make header editing simpler and keep it separate from the generator.

## Light/dark mode update
- Added a moon/sun toggle in the header, following the main site’s control.
- Uses device preference initially and remembers an explicit selection.
- Updated lesson panels, inputs, code output, exercises, quizzes and SVG memory diagram colours. Printing remains light.
- Verified switching, reload persistence, blocked storage, both existing DOM suites, and desktop browser appearance.
- Counter connection remains pending the account address; no popularity panel added.

## Shared counter integration
- Connected to manafhgh.goatcounter.com with no API key in the page.
- Added subtle overall/selected-topic counters above the footer; no visible labels or popularity panel.
- Counted repeat visits, direct links and topic returns; excluded subsection movement and local previews.
- Used a separate overall path to avoid adding topic records twice.
- Verified routing and failure behaviour with mock transport, plus both lesson regression suites.
- Live public-counter endpoint returned 403 requiring the account’s Allow adding visitor counts setting. Display is therefore not yet verified against live counts.

## New counter display fix
The live service returned cached HTTP 404 with valid zero-count JSON. Accept that specific response so the service’s zero is visible, while still rejecting disabled (403), malformed, and failed responses. Added a regression check.

## Counter retrieval repair and requested wording cleanup
- Verified live default responses were zero, while the explicit all-course date range returned overall 25 and Classes 1.
- Use that explicit range; expire browser cache after five minutes on the next navigation. No duplicate tracking snippet.
- Applied deferred requests: removed Dr. before Manaf Gharaibeh and the Classes navigation Guided badge.

## Remove public counters
Removed displayed numbers, public count fetching, and associated CSS. Kept overall and per-topic tracking with the same existing paths for dashboard access and history continuity.
