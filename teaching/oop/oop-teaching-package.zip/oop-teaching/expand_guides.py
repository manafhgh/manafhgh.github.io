"""Author the guided content and migrate Point examples to double coordinates."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parent/'teaching/oop'
topics=json.loads((root/'topics.json').read_text());examples=json.loads((root/'content.json').read_text());optional=json.loads((root/'optional.json').read_text());model=json.loads((root/'model.json').read_text())
guides={}
def g(id,prereq,goals,sections,trace,experiments,mistakes,checks):
    guides[id]=dict(prerequisites=prereq,goals=goals,sections=[dict(title=h,text=b) for h,b in sections],trace=trace,experiments=[dict(task=a,answer=b) for a,b in experiments],mistakes=mistakes,quiz=[dict(prompt=q,options=o,correct=c,explanation=e) for q,o,c,e in checks])

g('functions','Variables, assignment, and basic expressions.',
['Choose value or reference parameters deliberately.','Call pointer parameters using valid addresses.','Recognize overloads and trailing default arguments.'],[
('A parameter is a local name','With `int a`, the function receives a copy of the argument’s value. Reassigning a changes that copy. With `int& a`, a refers to the caller’s object, so assignment changes the original. Use references when an operation intentionally updates the caller.'),
('Addresses are values too','A pointer parameter receives a copy of an address. Changing `*p` updates the pointed-to object; changing p itself only changes the local pointer. A swap using pointers requires valid, non-null addresses. A const reference allows observation without changing the argument and can bind to a literal.'),
('One name, several calls','Overloads have different parameter lists; return type alone cannot distinguish them. Default arguments fill omitted trailing parameters. A function with `sum(int x, int y=10)` still needs x. Match argument types explicitly, such as `2.5f` for float.')],
['Start with x=5 and y=10. swapValue receives independent copies.','The copies exchange values, but the caller still has 5 and 10.','swapReference receives aliases and changes the caller to 10 and 5.'],
[('Change swapReference parameters from int& to int. Predict the caller’s final values.','The function changes only copies; the caller remains unchanged.'),('In the pointer swap, try swapping the same variable with itself.','Both parameters refer to the same int. The temporary preserves its value, so it stays unchanged.')],
['A non-const lvalue reference cannot bind to an integer literal.','Giving an argument a default does not create a second overload.'],[
('Which parameter lets f modify the caller’s int?', ['int x','int& x','const int& x'],1,'A non-const reference aliases the caller’s variable.'),
('What does f(int* p) copy into its parameter?',['The pointed-to allocation','An address value','The entire caller’s stack'],1,'The pointer is passed by value; dereferencing it can still reach the caller’s object.'),
('For sum(int x,int y=10), which call is invalid?',['sum(5)','sum(5,20)','sum()'],2,'x has no default argument.')])
g('recursion','Function calls, conditionals, and integer arithmetic.',
['Identify a base case.','Show that each recursive call makes progress.','Trace work before and after a recursive call.'],[
('A recursive call solves a smaller problem','A recursive function calls itself with a smaller or simpler input. In sum(n), the smaller problem is sum(n-1). Every active call has its own parameters and local state. A base case gives a result without another recursive call.'),
('Progress is part of correctness','For nonnegative n, decreasing n reaches zero. If a function only checks n==0 and starts with a negative input, decrementing moves away from the base case. State the valid input range or reject invalid input. Deep recursion can exhaust stack space even when a mathematical answer exists.'),
('Unwinding reverses the order of pending work','printN first calls printN(n-1), then prints n. Printing waits until the smaller call returns. For n=3 the calls descend through 3,2,1,0, then print 1,2,3 as they return. Moving the print before the call produces descending order.')],
['sum(3) needs 3+sum(2).','sum(2) needs 2+sum(1), and sum(1) needs 1+sum(0).','sum(0)=0; returning upward gives 1, then 3, then 6.'],
[('Move cout before the recursive call in printN.','For input 5 the output becomes 5 4 3 2 1.'),('Change the recursive step in sum to sum(n). Why does it fail?','The input never approaches the base case. Do not run it with a large limit; reason about the missing progress first.')],
['A base case without progress is insufficient.','Recursive factorial quickly overflows fixed-width integers; recursion does not provide unlimited precision.'],[
('What is the base result for factorial(0)?',['0','1','It must recurse forever'],1,'The empty product is 1, which also makes factorial(1)=1×factorial(0).'),
('Why does printN print ascending values?',['It prints after the smaller call returns.','n increases in the recursive call.','All calls share one n.'],0,'The pending output happens during unwinding.'),
('Which call progresses toward a base case at n<=0 for positive n?',['f(n)','f(n+1)','f(n-1)'],2,'Reducing a positive n eventually reaches zero.')])
g('pointers','Variables, addresses, and function parameters.',
['Distinguish pointer value from pointed-to data.','Trace copied pointers and reseating.','Explain why a reference remains an alias.'],[
('Address versus value','An int variable stores an integer. An int* variable stores an address of an int, or a null pointer value. `&x` obtains x’s address; `*p` accesses the int p points to. A pointer declaration does not create a separate pointed-to int.'),
('Copying pointers does not copy targets','After `int* p2=ptr`, both pointers can refer to the same object. Writing through either changes that object. Reseating one pointer with `ptr=&y` changes only that pointer; it does not redirect p2.'),
('References are aliases','A reference must be initialized. After `int& num=x`, assigning `num=y` copies y’s value into x. It does not rebind num. A reference is not modeled as a separately reseatable pointer, and C++ does not require it to occupy its own storage cell.'),
('Validity before dereferencing','Initialize unused pointers to nullptr. Dereference only a valid pointer to a live object of the appropriate type. A non-null pointer can still be dangling after its target dies. Neither null nor dangling pointers may be used to access an int.')],
['ptr and p2 initially both store &x.','*ptr=100 changes x and the value observed through its alias num.','ptr=&y changes only ptr; later *p2 still updates x.'],
[('In the walkthrough change *p2=42 to *ptr=42 before ptr becomes null.','ptr targets y at that point, so y changes instead of x.'),('Compare &num and &x after num=y.','They remain equal because num still names x, even though a value was copied from y.')],
['Assigning a pointer changes its target; assigning through * changes target data.','Equal object values do not imply equal object addresses.'],[
('After p2=ptr and ptr=&y, where does p2 point?',['It follows ptr to y.','It keeps ptr’s previous target.','It becomes null.'],1,'Pointer assignment copies an address at that moment.'),
('What does num=y do if num is a reference to x?',['Rebinds num to y.','Copies y’s value into x.','Creates a new int.'],1,'References cannot be reseated by assignment.'),
('Which pointer is safe to dereference?',['Any non-null pointer','A pointer to a live, accessible int','A pointer after delete'],1,'Non-null alone does not establish validity.')])
g('constants','Pointer declarations and assignment.',
['Read const at each level of a declaration.','Choose read-only access without freezing the original object.','Separate const pointer from pointer-to-const.'],[
('Protecting the data through an access path','`const int* p` means p points to an int that cannot be modified through p. The int itself may have been declared mutable. Another permitted access path can still modify that int. You may reseat p to another compatible address.'),
('Protecting the pointer object','`int* const p=&x` fixes p’s stored address after initialization. x can still change through *p. `const int* const p=&x` combines both restrictions. Read a declaration by asking separately whether the pointer can move and whether the pointed-to data can be written through it.'),
('Const is checked by the compiler','A commented forbidden assignment is useful as an experiment: uncomment one at a time, read the diagnostic, then restore valid code. Const is a design promise enforced by type rules, not a reason to cast restrictions away.')],
['ptr first points to const z; *ptr cannot be assigned.','Reseating ptr to mutable x is allowed, but writing through ptr remains prohibited.','The separate const pointer p stays at &x while *p=66 updates x.'],
[('Uncomment the attempted reseating of int* const p.','The compiler rejects assigning a new address to a const pointer.'),('Change x directly while const int* ptr points to it, then print *ptr.','The new value is visible. The pointer-to-const restricts this access path, not all access to x.')],
['A const pointer needs initialization.','const int* does not mean the pointer itself is constant.'],[
('Which declaration allows reseating but prohibits *p=7?',['int* const p=&x','const int* p=&x','const int* const p=&x'],1,'The pointed-to data is const through p; p is mutable.'),
('Can int* const p=&x modify x through *p?',['Yes, if x is mutable.','No, every const protects the target.','Only after a cast.'],0,'The const applies to the pointer object.'),
('Which protects both levels?',['const int* const p=&x','int* p=&x','int const value=3'],0,'One const qualifies the int and the other qualifies the pointer.')])
g('scope','Functions and local/global variables.',
['Resolve shadowed names.','Distinguish scope from lifetime.','Use a static local to retain state across calls.'],[
('Scope answers where a name is visible','A local declaration can hide a global variable with the same name. Before the local declaration, x can refer to the global. After it, x refers to the local within its scope. `::x` explicitly names the global x.'),
('Lifetime answers when an object exists','An ordinary local variable in a function is initialized on each call and its lifetime ends on return. A static local has static storage duration; it is initialized once and retains its state between calls. Its name is still local to the function.'),
('Trace the two ideas separately','In foo, ordinary x starts at 1 for every call. Static y starts at 1 once and is incremented across calls. A static local is useful for a simple counter, but hidden mutable state can make repeated calls and tests less independent.')],
['fun prints global x=5, then local x=100, then ::x=5.','The first foo call prints 1 1 and increments its locals.','Later calls reinitialize x but retain y, printing 1 2 and 1 3.'],
[('Remove static from y and call foo three times.','Both locals restart at 1, so each call prints 1 1.'),('Rename the local x in fun so it no longer shadows the global.','Unqualified x resolves to the global where no local x exists. The explicitly named local can be printed separately.')],
['A long-lived object does not necessarily have a globally visible name.','Changing a local variable does not change a shadowed global variable.'],[
('What does ::x select?',['The nearest local x','A global x','A static local x'],1,'The leading scope-resolution operator selects the global namespace.'),
('When is a static local initialized?',['Once, when initialization is first required','On every call','Only after main returns'],0,'It retains its state after that initialization.'),
('What does an ordinary local initialized to 1 do on each call?',['Keeps its previous value','Starts at 1 again','Becomes global'],1,'Each invocation has its own ordinary local lifetime.')])
g('arrays','Loops, array indexing, and basic recursion.',
['Respect the half-open index range [0,n).','Explain partial array initialization.','Pass a size alongside an array parameter.'],[
('Contiguous elements, bounded indices','An array of n elements has valid indices from 0 to n-1. A loop with i<n visits each element once. Reading or writing a[n] is out of bounds. Array subscripting does not perform a built-in bounds check.'),
('Initialization fills missing elements','`int a[5]={1,2,5};` creates {1,2,5,0,0}. `int b[]={1,2,5};` deduces a length of 3. An uninitialized automatic int array is different: do not assume its elements are zero.'),
('An array parameter does not retain its size','A parameter written int a[] is adjusted to an int* parameter. Pass n separately and keep it within the real array size. `sizeof(a)/sizeof(a[0])` computes a count for an actual array object, but not for that pointer parameter. sizeof is an operator.'),
('Two sum strategies','Iteration keeps a running total. Recursion sums a prefix of length n-1 and adds a[n-1], stopping at an empty prefix. Both process n elements, but the recursive version also uses call-stack space.')],
['Initialize a1 to 1,2,5,0,0.','The iterative total becomes 1,3,8,8,8.','The recursive base returns 0; adding the same elements also returns 8.'],
[('Change the last two elements to 10 and -2. Compare both sum functions.','Both totals become 16.'),('Consider changing i<n to i<=n. Identify the first invalid access without running it.','The iteration at i==n accesses one element beyond the array.')],
['sizeof on an array parameter measures a pointer, not the caller’s array.','Zero is an even number in the count-even exercise.'],[
('How many valid indices does int a[5] have?',['0 through 5','1 through 5','0 through 4'],2,'Five elements use five zero-based indices.'),
('What are unspecified elements in int a[5]={1,2,5}?',['Zero','Indeterminate','Copies of 5'],0,'The remaining aggregate elements are value-initialized.'),
('Why pass n to a function receiving int a[]?',['The parameter does not retain the array length.','Every array must have five elements.','sizeof will always return n.'],0,'The parameter is adjusted to a pointer.')])
g('console-io','Variables, strings, and conditionals.',
['Use formatted extraction and line input appropriately.','Validate a stream before using input.','Format decimal output deliberately.'],[
('Streams are interfaces to input and output','Include <iostream> for cin, cout, and cerr. Extraction with >> converts input into a requested type; insertion with << writes a value. Chain the operators to process several values. The supplied programs use the std namespace through a using directive.'),
('Words versus lines','`cin >> name` stops at whitespace. `getline(cin,name)` reads a complete line, which is useful for full names. Numeric extraction typically leaves a newline in the stream. Discard the rest of that line with ignore before a following getline when the format uses separate lines.'),
('Check conversion and range separately','`if (!(cin>>grade))` detects failed conversion. A successful conversion can still produce an out-of-range grade, so validate the domain too. The examples report errors and return rather than implement retry loops. A retry loop would clear the error state and discard invalid input.'),
('Make output predictable','With fixed and setprecision(1), one digit appears after the decimal point. Enter all input in the page’s input box before running: this service uses batch input, not a terminal that pauses for new keystrokes.')],
['getline reads Manaf Gharaibeh as one name, including its space.','The numeric extraction reads 85.5 and the range test accepts it.','The formatter prints the name and grade with one fractional digit.'],
[('Enter a word instead of a numeric grade.','Extraction fails and the program reports Invalid grade instead of using a failed conversion.'),('Remove ignore from the mixed-input example.','getline consumes the newline left by the numeric extraction and yields an empty name.')],
['A prompt printed by cout does not automatically validate input.','setprecision without fixed has different formatting semantics: significant digits.'],[
('Which reads a full name including spaces?',['cin >> name','getline(cin,name)','cout << name'],1,'getline reads through the line delimiter.'),
('What can remain after cin >> id?',['A newline waiting to be read','No whitespace under any circumstances','An extra int object'],0,'A subsequent getline can see this newline.'),
('What does fixed with setprecision(1) mean?',['One digit after the decimal point','One digit total','Round all values to integers'],0,'fixed gives precision the meaning of fractional digits.')])
g('text-files','Console streams, loops, and strings.',
['Open and check file streams.','Distinguish replacement from append mode.','Read complete records and close a writer before reading.'],[
('Files use the same stream operations','Include <fstream>. ofstream writes, ifstream reads, and fstream can support both. Once open, use <<, >>, or getline just as with console streams. Test the stream after opening; an invalid path or insufficient permissions can cause failure.'),
('A path is relative to the working directory','grades.txt means a file in the program’s working directory, which need not be the source directory. The online run has its own sandbox; it cannot access your computer’s files. The example creates its input file during the same run. Download and run locally to retain it.'),
('Choose whether to replace or append','Normal ofstream opening truncates an existing file. ios::app adds to its end. Close the writer and check its state before opening a reader so buffered data has been flushed. Stream destruction also closes a file automatically.'),
('Read operations determine success','Do not loop using !eof() to predict whether the next extraction will work. Test extraction itself and process only complete records. This format uses one word for a name and a numeric grade; a different format is needed for names containing spaces.')],
['Write Amal 85 and Lina 92, then close the output stream.','Read each complete record and accumulate total=177, count=2.','The computed average is 88.5. The exercise appends Omar 78 and changes the average to 85.0.'],
[('Add a third record before the writer closes.','The reader sees all three records and includes each in the average.'),('Replace a grade in the written data with text.','The grade extraction fails and the program reports an invalid record instead of processing it.')],
['Online files do not persist reliably between separate Run actions.','Opening a writer in the default mode can erase an existing file’s contents.'],[
('Which stream type writes a text file?',['ifstream','ofstream','istream only'],1,'ofstream is the output file stream type.'),
('What does ios::app request?',['Append at the end','Delete the file first','Read the file backward'],0,'Append mode preserves earlier contents.'),
('Why close the writer before opening the reader?',['To flush pending output and finish writing','To convert the path to an absolute path','To make every name a string'],0,'Buffered writes must be completed before the reader relies on them.')])
g('lifetime','Classes, constructors, and function arguments.',
['Trace construction and destruction by scope.','Recognize a copy constructor.','Compare value and const-reference parameters.'],[
('Each object has a lifetime','A constructor establishes a new object. A destructor runs when that object’s lifetime ends. Ordinary local objects are destroyed when their scope ends, in reverse order of completed construction. A nested scope makes these boundaries easy to observe.'),
('Copy construction creates another object','`Point p2(p1)` initializes a new object using p1. A conventional copy constructor receives const Point& so it can copy const objects and does not recursively copy its own argument. This simple Point copies coordinate values.'),
('Parameters can introduce lifetimes too','Passing the lvalue p1 by value constructs a separate parameter object; the example logs its construction and destruction. Passing const Point& binds to the existing object without copying it. Do not infer mandatory extra copies from return statements: copy elision can remove them.')],
['Construct p1.','byValue copies p1 into its parameter, prints it, then destroys that copy.','byReference prints without copying; p2 is explicitly copied and is destroyed before p1.'],
[('Put a Point inside braces and print a message after the closing brace.','The inner destructor runs before the message.'),('Compare logging for byValue(p1) and byReference(p1).','Only the value call constructs a parameter copy of this lvalue.')],
['Assignment to an existing object is not copy construction.','Destructor order is about object lifetimes, not variable names alphabetically.'],[
('Which creates a new copy of p1?',['Point p2(p1);','p1.printPoint();','const Point& r=p1;'],0,'p2 is a new object initialized from p1.'),
('What is destroyed first for two locals constructed a then b?',['a','b','Both simultaneously'],1,'Locals in one scope are destroyed in reverse construction order.'),
('Does binding const Point& to this existing lvalue copy it?',['Yes, always','No','Only if Point has two coordinates'],1,'The reference binds to the existing object.')])
g('interface','Class declarations, member functions, and separate compilation.',
['Separate declarations from definitions.','Use include guards.','Compile and link every implementation file.'],[
('The interface tells callers what exists','A header declares the Point type and its public members. Callers can compile uses of those members using the declarations. Definitions supply the actual constructor and function bodies. Keeping implementation separate makes the interface easier to scan.'),
('Definitions name their class','Outside the class, write Point::distanceTo to indicate which class the function belongs to. Keep the signature consistent with the declaration, including parameter types and trailing const. Include point.h in both main.cpp and point.cpp.'),
('Headers and linking solve different problems','An include guard prevents repeated class definitions within a translation unit. It does not replace linking. Build main.cpp and point.cpp together so the linker finds the declared function definitions. The page combines the files for one-click execution; the ZIP contains a real multi-file project.')],
['Read the Point declaration to find the available constructor and distanceTo query.','Find their Point:: definitions in the implementation portion.','main constructs (3,4) and the origin, then prints distance 5.'],
[('Add a getter declaration without adding its definition, then call it.','The call can compile using the declaration, but linking fails without a definition.'),('Remove trailing const from only the definition of a const query.','The definition no longer matches the declaration; the compiler reports the mismatch.')],
['Do not put ordinary non-inline function definitions in a widely included header without considering multiple definitions.','A successful compilation of main.cpp alone does not prove the whole program links.'],[
('Where does a public member declaration normally belong?',['The class header','Only inside main','Only in a Makefile'],0,'The declaration forms part of the type’s interface.'),
('What does Point:: identify in a definition?',['A member of Point','A global variable','An array size'],0,'Scope resolution associates the function with the class.'),
('What must a build include for this real three-file project?',['main.cpp only','main.cpp and point.cpp','point.h as the executable'],1,'Both translation units are needed for the complete program.')])
g('object-arrays','Classes, arrays, and const queries.',
['Explain initialization of every array element.','Pass object arrays with bounds.','Define a tie policy when selecting an object.'],[
('Every element is an object','Declaring an array of Student or Point creates each element. Explicit initializers initialize early elements; remaining elements use the appropriate initialization, which in these examples calls a default-capable constructor. A pointer member inside an object would not automatically create a separate target.'),
('Construction and later updates differ','Initializing an array element from an existing object can use copy construction. Assigning to an already constructed element uses assignment. A const array parameter lets queries inspect elements without changing them; a separate size still describes the valid range.'),
('Selection needs a clear contract','closestToOrigin starts with element 0, so it requires a nonempty array. It compares candidate distances against the current best. A strict < keeps the first tied point; <= chooses the last tied point. Returning by value gives the caller a result independent of the array’s lifetime.')],
['For the five-point example, begin with (3,4) as the best candidate.','(1,1) has a smaller distance and replaces it.','No later candidate is closer, so the function returns (1,1).'],
[('Create two points equally close to the origin and compare < with <=.','The first or last tied candidate wins according to the comparison.'),('Consider size=0 for a function starting best=0.','The precondition is violated. Redesign the interface or reject the call rather than access element 0.')],
['A result-selection function needs an explicit empty-input policy.','An array of objects does not give a function its size automatically.'],[
('What happens to unlisted elements in these default-capable object arrays?',['They are omitted from the array','They are initialized using the class’s available default initialization','They are always null pointers'],1,'Every array element exists as an object.'),
('With strict <, which tied candidate stays best?',['The first','The last','A random one'],0,'Equality does not replace the previous best.'),
('Why does closestToOrigin require size>0?',['It initializes its best index to 0','It cannot call getters','A Point must be dynamic'],0,'The algorithm assumes an initial element exists.')])
g('temperature','Classes, const members, arrays, and averages.',
['Initialize a const data member.','Convert readings differently from temperature changes.','Average mixed-unit readings in a common unit.'],[
('The unit is part of the object’s contract','A Temperature stores an immutable scale and a mutable reading. The const scale must be initialized before the constructor body, through the initializer list. Valid scales are C and F. Queries are const and can observe either representation.'),
('A reading includes an offset','An absolute Fahrenheit reading converts as (F-32)×5/9. An absolute Celsius reading converts as C×9/5+32. For example, 0°C and 32°F represent the same temperature.'),
('A change has no 32-degree offset','An increase of 18°F equals an increase of 10°C. Convert differences using only the scale factor. changeT adds that converted difference to the existing reading. Applying the absolute-reading formula to a difference produces the wrong change.'),
('Average comparable quantities','Convert all readings to Celsius before adding. Initialize the accumulator to zero and reject an empty array before dividing by its size. The example throws on invalid input; its ordinary demonstration inputs are valid.')],
['Convert each array element to Celsius, even if its stored scale is F.','Add the converted readings into an initialized sum.','For changeT(F,18) on 0°C, add 18×5/9=10, giving 10°C.'],
[('Apply an increase of 10°C to a 32°F object.','The difference is 18°F, so the stored reading becomes 50°F.'),('Try an invalid unit or an empty array, with a try/catch if needed.','The validation rejects the call instead of silently guessing a scale or dividing by zero.')],
['Do not subtract or add 32 when converting a difference.','A const unit prevents default assignment from changing that member.'],[
('An increase of 18°F equals what Celsius increase?',['-7.78°C','10°C','50°C'],1,'Temperature differences use 18×5/9 without an offset.'),
('Where must scale_type be initialized?',['Only in a setter','In the constructor initializer list','After construction through assignment'],1,'A const data member must be initialized before the constructor body.'),
('How should mixed-unit readings be averaged?',['Average the stored numbers directly','Convert them all to the same unit first','Discard Fahrenheit values'],1,'The numbers must represent the same unit before arithmetic.')])
g('static','Object construction, copying, and const member functions.',
['Distinguish shared class data from instance data.','Maintain a live-object counter.','Explain access through a static member function.'],[
('One shared member, many objects','Box::count belongs to the class rather than to each object. Every Box observes the same count. Length, width, height, and color belong to individual objects. A static member can be accessed through the class name even before any Box exists.'),
('Count lifetime events consistently','Increase the count in every constructor that creates a live object, including a copy constructor. Decrease it in the destructor. Assignment changes an existing object and should not increase the live count. A live count differs from a cumulative total ever constructed.'),
('Static functions have no calling object','A static member function has no this pointer, so it cannot directly read a particular Box’s length. A const member function restricts access to ordinary instance state through this; it can still modify shared static data. The retained modifyCount method demonstrates access rules but would break the live-count meaning if called.')],
['Before constructing Boxes, getCount returns 0.','Each construction, including a copy, increments the same shared counter.','When nested-scope Boxes die, the counter drops back to its earlier value.'],
[('Construct a Box copy inside a nested scope and print counts on each side.','The count increases during the scope and decreases when the copy is destroyed.'),('Call getCount through the class name instead of an object.','It returns the same shared count without requiring an instance.')],
['A static counter is not automatically maintained: constructors and destructors must update it.','const does not mean a member function cannot affect any external or shared state.'],[
('How many count data members exist across three Boxes?',['Three','One shared member','None until getCount is called'],1,'Static data is shared by all instances of the class.'),
('Should ordinary assignment increment a live-object count?',['Yes','No','Only for const objects'],1,'Assignment updates an already-live object.'),
('Can a static function directly read an instance length with no object?',['Yes','No','Only if count is zero'],1,'It needs a specific object to access non-static data.')])
g('composition','Classes, constructors, const references, and copying.',
['Model a has-a relationship.','Initialize member objects directly.','Distinguish stored values from references.'],[
('A Line has Points','Composition builds one object from member objects. Line contains a start Point and an end Point. This is a has-a relationship, unlike inheritance’s is-a relationship. The member Points are part of the Line object and have lifetimes tied to it.'),
('Members are ready before the body','Use the Line initializer list to construct start and end directly. Members are initialized in their declaration order, not the order written in an initializer list. Constructor parameters received by const reference avoid unnecessary parameter copies.'),
('Value members are independent copies','The Line stores Point values. Changing the original argument b afterward does not alter Line’s stored end. Storing references or pointers would express a different relationship with different lifetime requirements. length can be const because it only queries the member Points.')],
['Construct original a=(0,0), b=(3,4).','Line’s initializer list copies them into start and end.','length queries those stored endpoints and returns 5.'],
[('Change original b to (6,8) after creating the Line.','The existing Line’s length stays 5 because it stores copied Points.'),('Build a second Line after changing b.','The second Line stores the updated endpoint and has length 10.')],
['Changing constructor arguments later does not change value members already copied from them.','Initializer-list order does not override member declaration order.'],[
('What relationship does Line containing two Points express?',['is-a','has-a','Neither object exists'],1,'The Points are components of a Line.'),
('When are member Points constructed?',['After the Line constructor body','Before the Line constructor body','Only when length is called'],1,'Member initialization precedes the body.'),
('Does changing original b change a Line storing b by value?',['Yes','No','Only if b has double coordinates'],1,'The stored value is a separate object.')])
g('dynamic','Pointers, arrays, and object lifetimes.',
['Separate pointer lifetime from target lifetime.','Match allocation and deallocation forms.','Identify dangling aliases and avoid leaks.'],[
('Allocate storage when needed','new int(7) creates a dynamic int and returns its address. new Point creates a Point and runs its constructor. A local pointer variable and its dynamic target are separate objects with separate lifetimes. Losing the only owning address before deletion leaks the allocation.'),
('Delete the target, not the pointer variable','delete p ends the target’s lifetime and releases its storage. It does not remove the local variable p or set p to nullptr. Copied pointers to that allocation also become dangling. Reset each retained pointer without dereferencing it.'),
('Arrays require matching operations','Use delete[] for a target created with new[]. Index only within the allocated array. Value-initialize basic arrays with braces when you need defined starting values. Deleting an address of an ordinary local object is invalid.'),
('Prefer explicit ownership','These raw-pointer examples teach mechanics. In practical code, standard containers and smart pointers often express ownership more safely. The next lesson shows why an owning raw pointer makes copying a class more complicated.')],
['Allocate A and copy its address into alias.','delete p releases A; both p and alias become dangling until reset.','Allocate a separate array B, update its second element, then release it with delete[].'],
[('After resetting p, ask whether alias was reset too.','No. Assignment to one pointer does not update another pointer’s stored value.'),('Replace new Point[3] with a local Point array and reason about delete[].','A local array is not allocated by new[] and must not be deleted manually.')],
['A non-null pointer can still be dangling.','Setting a pointer to nullptr without first releasing its sole allocation can leak it.'],[
('What does delete p release?',['The pointer variable itself','The dynamic target allocated with new','All aliases automatically'],1,'The pointer variable remains in its own scope.'),
('Which matches new Point[3]?',['delete points','delete[] points','free(points)'],1,'Array allocation must be paired with array deletion.'),
('After delete p, what happens to an alias copied earlier?',['It becomes nullptr automatically','It is dangling','It owns a new copy'],1,'Its former target no longer exists.')])
g('ownership','Dynamic arrays, constructors, destructors, and references.',
['Explain shallow-copy failures for owning pointers.','Implement the Rule of Three.','Check independent copies and self-assignment.'],[
('Ownership creates obligations','Student owns a dynamic grade array and is responsible for releasing it. The constructor validates a positive length and initializes the array. The destructor releases it exactly once. A pointer member by itself does not encode this ownership rule.'),
('A shallow copy duplicates an address','Compiler-generated copying of a raw pointer copies the address, so two owning Students can unintentionally share one allocation. Changes affect both, and destruction may attempt double deletion. A deep copy allocates a fresh array and copies the elements.'),
('The Rule of Three covers all ordinary copy paths','If this class needs a custom destructor, it also needs copy construction and copy assignment. The assignment operator handles self-assignment, allocates replacement storage before discarding the old storage, and returns *this by reference. Allocation-first preserves the old state if allocation throws.'),
('Use a safer default when possible','For production code, std::vector can manage the grade storage and let the class use ordinary generated special members: the Rule of Zero. This raw-array version is a focused ownership exercise, not a recommendation to reinvent every container.')],
['Read 70,80,90 into a’s array.','Copy-construct b with a different allocation, then increase only b’s first grade to 75.','Assign a into c using deep-copy assignment; a and c keep average 80 while b differs.'],
[('Assign a to itself before printing.','The guard prevents discarding its own source data, and values stay intact.'),('Change b after b=a and print both objects.','Only b changes if assignment made an independent array.')],
['A destructor alone does not make an owning pointer safe to copy.','Do not divide by a zero grade count; the constructor rejects nonpositive counts.'],[
('What does a shallow pointer copy share?',['Only the element count','The same target allocation','A newly allocated array'],1,'The address is copied without duplicating its target.'),
('Which three operations are handled here?',['Destructor, copy constructor, copy assignment','Getter, setter, print','new, cout, return'],0,'These define release and ordinary copy behavior.'),
('Why allocate replacement storage before deleting old storage?',['To preserve the current object if allocation fails','To force a shallow copy','To avoid constructors entirely'],0,'The old state survives a failed allocation.')])
g('friends','Public/private access and function declarations.',
['Distinguish a friend function from a member.','Use forward declarations when types depend on each other.','Limit access grants to the intended interface.'],[
('Friendship grants access','A friend function can access a class’s private and protected members without becoming a member of that class. A two-class add function is declared as a friend by both classes, so the same function can read both private numbers.'),
('Declarations must be known in the right order','A forward declaration makes the name ClassB known before ClassA names it in a function signature. For a friend member function, its class must declare that member before another class can name the specific member as a friend. The function body can follow the complete class definitions.'),
('Grant the access actually needed','friend class B grants access to all B members. Naming one B member grants narrower access. Friendship is not reciprocal, transitive, or inherited. It is a deliberate interface choice, not a substitute for every public operation.')],
['ClassA initializes its private number to 500; ClassB uses 166.','Both authorize the same non-member add function.','add reads their private values and returns 666.'],
[('Remove friend authorization from one class and compile the add function.','Access to that class’s private member is rejected.'),('Move the definition of the friend function after both complete class definitions.','Both member layouts are then known when its body accesses them; the forward declaration remains useful for the earlier signature.')],
['A friend declaration does not make access reciprocal.','A non-member friend is called as a normal function, not automatically with object.method syntax.'],[
('Does a friend function become a class member?',['Yes','No','Only if it returns int'],1,'It gains access while retaining non-member identity.'),
('If B is a friend of A, is A automatically a friend of B?',['Yes','No','Only with two data members'],1,'Friendship is not reciprocal.'),
('What is narrower than friend class B?',['Naming a specific B member function as a friend','Making all data public','Granting friendship to every class'],0,'Only the named function receives access.')])
g('this','Member calls, references, and returned values.',
['Interpret this and *this.','Trace returned copies versus returned aliases.','Use reference returns safely for chaining.'],[
('The calling object is available through this','In a non-static member function, this points to the object on which the function was called. *this names that object. A parameter can have the same name as a member; this->x explicitly selects the member x.'),
('A value result is independent','Returning A by value creates a value result. In a.byValue().boo(), boo operates on that returned value rather than the original a. A returned reference, A&, aliases the original object; a.byReference().boo() then updates a.'),
('Chaining needs meaningful lifetime','Returning *this by reference from a mutator allows consecutive calls on one object. Do not return a reference to a local object that dies at the end of the function. A valid returned reference must not be used after its original object is destroyed.')],
['a begins with x=5.','byValue().boo() changes a temporary; a.print still shows 5.','byReference().boo() changes a itself to 60.'],
[('Change the reference-returning function’s return type to A.','It returns a value instead, so a following mutation no longer changes the original object.'),('In add(int), return *this by reference and chain two additions.','Both calls operate on the same object and their effects accumulate.')],
['this is a pointer; *this refers to the object.','A reference return is unsafe if its target’s lifetime has ended.'],[
('What is this in a non-static member function?',['A pointer to its calling object','A copy of the calling object','A global class name'],0,'It identifies the specific object for the call.'),
('What does A& byReference() return here?',['An alias to the original object','Always a new allocation','A null pointer'],0,'return *this binds the reference result to the caller.'),
('May a function safely return a reference to its ordinary local A?',['Yes, always','No, it would dangle after return','Only if A is small'],1,'The local lifetime ends when the function returns.')])
g('inheritance','Classes, access control, and constructor initializer lists.',
['Model public inheritance as an is-a relationship.','Initialize a base subobject.','Trace base/derived construction and destruction.'],[
('A derived object includes a base subobject','An UnderGrad is a Student in this public-inheritance example. Its Student subobject still contains private base data, but derived member functions cannot access that private data directly. They can call appropriate accessible base functions.'),
('Access has two dimensions','A member’s public/protected/private declaration controls who can access it. The inheritance access mode controls how accessible base members are inherited. With public inheritance, base public stays public and protected stays protected. Base private remains inaccessible directly to derived code.'),
('Build the base before the derived part','The UnderGrad initializer list calls Student’s constructor before the derived constructor body. If omitted, a viable default base constructor is required. Destruction runs the derived destructor before the base destructor. A virtual base destructor supports safe deletion through a base pointer.'),
('Hiding is different from overriding','This print example explicitly calls Student::print, then prints the training company. A same-named non-virtual function in a derived class hides rather than dynamically overrides the base function. Virtual dispatch is developed in the next lesson.')],
['Construct the Student base portion for Leila first.','Construct the UnderGrad portion and store its training company.','Print the base data and company; destruction logs derived before base.'],
[('Remove the explicit Student initializer and observe which base constructor runs.','If the base is default-capable, its defaults are used; otherwise construction would fail.'),('Try direct access to the base’s private ID from UnderGrad.','The compiler rejects it; the base data exists but is not directly accessible.')],
['Public inheritance does not make private base members public.','A same name is not enough for dynamic overriding; the base function must be virtual.'],[
('Which constructor runs first?',['Derived body','Base constructor','Neither until print'],1,'The base subobject must be initialized first.'),
('Does private base data disappear from a derived object?',['Yes','No; direct derived access is restricted','Only when copying'],1,'It remains part of the base subobject.'),
('What does public inheritance aim to express?',['has-a','is-a','points-to'],1,'The derived type can be used as its public base type.')])
g('polymorphism','Public inheritance, pointers, and object lifetimes.',
['Call overrides through a base interface.','Recognize abstract classes.','Explain override and virtual destruction.'],[
('One interface, several behaviors','Animal declares a virtual makeSound operation. Cat, Dog, and Penguin supply their own implementations. A call through Animal* selects the final override for the actual object, so a base-pointer collection can process different concrete animals uniformly.'),
('Pure virtual functions define an abstract interface','A pure virtual declaration ends with =0. A class with an unimplemented pure virtual function is abstract and cannot be instantiated. A derived class must implement all inherited pure virtual operations to become concrete. The base can still contain ordinary implemented queries and data.'),
('Let the compiler check intent','override asks the compiler to verify that the signature actually overrides a base virtual function. A virtual destructor ensures the full derived object is destroyed when deletion occurs through a base pointer. Non-owning pointers to local animals must not be deleted.'),
('Language semantics versus optimization','Virtual dispatch is the language behavior even when a concrete object is known. A compiler may optimize a call by devirtualization; avoid treating every direct object call as necessarily non-virtual. Choose the design for correct behavior before reasoning about performance.')],
['Construct concrete animals with species information.','Store their addresses in Animal* variables and invoke makeSound.','Release only the dynamically allocated Cat; local animals are destroyed by scope.'],
[('Add Cow and mark makeSound override. Call through Animal*.','The Cow override runs and prints its own sound.'),('Misspell the override signature while keeping override.','Compilation fails, revealing that the intended override does not match.')],
['Do not instantiate Animal while it remains abstract.','Do not delete a pointer merely because it has a base type; ownership and allocation still matter.'],[
('What selects the virtual override through Animal*?',['The actual object’s type','Only the pointer variable’s name','Array length'],0,'Runtime polymorphism follows the dynamic object type.'),
('What does =0 on the virtual operation mean?',['Pure virtual','Return zero automatically','Static member'],0,'The declaration makes this an abstract operation.'),
('Why use override?',['To check the intended override signature','To allocate memory','To make a private member public'],0,'It catches accidental signature mismatches.')])
g('casting','Polymorphic base classes and pointer validity.',
['Distinguish upcasting from slicing.','Check dynamic_cast before use.','Explain pointer-cast and reference-cast failure.'],[
('Upcasting preserves an object through a view','A derived pointer or reference can convert to an accessible unambiguous base pointer or reference. The object itself remains derived, enabling virtual calls. Copying by value into a base object instead can slice off the derived part.'),
('Downcasting makes a stronger claim','A base pointer does not prove the target has a particular derived type. dynamic_cast can check suitable conversions using a polymorphic base. For a failed pointer cast it returns nullptr. Test that result before calling derived-specific behavior.'),
('Reference failure is reported differently','A failed reference dynamic_cast throws std::bad_cast because a reference cannot represent a null result. An unchecked downcast with static_cast is not a runtime validation. Prefer a virtual interface when the desired operation belongs naturally to all derived types.')],
['shape_ptr refers to a Rectangle through Shape*.','The checked Rectangle* conversion succeeds and draws it.','The Circle* conversion fails, so the program prints a failure message instead of dereferencing nullptr.'],
[('Allocate Circle instead of Rectangle without changing the casts.','The successful and failed cast cases swap.'),('Remove a null check before a failed cast’s use. Reason about the result without executing invalid code.','A member call through the null result is invalid; keep the check.')],
['static_cast does not verify the runtime object type.','A cast does not allocate a new object or transfer ownership.'],[
('What does a failed pointer dynamic_cast return?',['nullptr','An unrelated new object','Always a thrown exception'],0,'Check the pointer before using it.'),
('What happens on a failed reference dynamic_cast?',['A null reference is returned','std::bad_cast is thrown','The object becomes a Circle'],1,'A reference conversion reports failure through an exception.'),
('What can happen when copying a derived object into a base object by value?',['Object slicing','Automatic polymorphic duplication','No base data is copied'],0,'Derived-specific state is not retained in the standalone base object.')])
g('multiple','Public inheritance and qualified names.',
['Distinguish multilevel from multiple inheritance.','Resolve ambiguous member names.','Choose inheritance only for meaningful interfaces.'],[
('Multilevel forms a chain','ResearchStudent derives from Student, which derives from Person. The object can use inherited public behavior through each appropriate base. Constructors initialize the complete chain before the most-derived constructor body.'),
('Multiple means more than one direct base','ResearchStudent also derives from Presenter, so it has two direct bases. Student contributes the Person relationship and study behavior; Presenter contributes presentation behavior. These independent capabilities are the intended reason for the second base.'),
('Names and shared bases need care','If two bases supply the same accessible member name, an unqualified call can be ambiguous; qualify the base or provide a deliberate derived operation. A diamond-shaped hierarchy can contain duplicate common base subobjects; virtual inheritance is a separate advanced design topic. Prefer composition when a component relationship is more accurate.')],
['Person stores the name passed through Student.','ResearchStudent initializes its Student base; Presenter provides its separate public capability.','The object introduces itself, studies, and presents.'],
[('Give Student and Presenter methods with the same name and try an unqualified call.','The call can be ambiguous; explicitly select the intended base or define a derived method.'),('Add teach to Presenter and invoke it on ResearchStudent.','The public inherited behavior is accessible through the derived object.')],
['Multiple and multilevel describe different shapes and can occur together.','Using several bases solely to reuse unrelated implementation can make a design harder to understand.'],[
('Which is multilevel?',['ResearchStudent → Student → Person','One class with Student and Presenter bases','An array of Students'],0,'Multilevel inheritance follows a chain.'),
('Which is multiple inheritance?',['Two Student objects','ResearchStudent with two direct bases','Two constructors in Person'],1,'The class directly inherits from more than one base.'),
('How can you resolve an ambiguous inherited member name?',['Qualify the intended base','Rename every object','Use delete'],0,'A qualified call makes the selection explicit.')])
g('operators','Member/non-member functions, const, and reference returns.',
['Preserve familiar operator meaning.','Distinguish unary and binary forms.','Return streams and updated objects for chaining.'],[
('Operators are functions with familiar syntax','An overloaded operator gives a user-defined type a meaning for an existing operator. It does not change precedence or the number of operands. At least one operand must have a user-defined type. Choose behavior that agrees with users’ expectations.'),
('Unary and binary operations differ','Unary - on Point returns negated coordinates without modifying the operand. Binary subtraction combines two Points. A binary member has its left operand as the calling object and receives the right operand as its explicit parameter; a non-member receives both.'),
('Queries and chaining have useful conventions','Equality returns bool and should not change operands. Assignment and += normally return a reference to the updated left operand. Output returns ostream& so another << can follow. Exact floating-point equality is demonstrated for exactly matching stored values; computed approximate geometry may need tolerance-based comparisons.'),
('Do not surprise the caller','The Student example uses comparisons for grade ordering. Its arithmetic operators are small syntax demonstrations, not a fully validated grade domain. A const query communicates that comparison and output should not change ordinary instance state.')],
['Negating p1 constructs a separate Point with negative coordinates.','Subtracting equal Points produces (0,0).','Chained assignment returns references to existing left operands; equality produces true or false.'],
[('Use p1 and p2 with different fractional coordinates. Predict their subtraction.','Subtract each coordinate independently; the original operands remain unchanged.'),('Try chaining the Student += result or stream << result.','The conventional reference return allows the next operation to use the updated object or the same stream.')],
['Overloading does not change operator precedence.','A truth-like integer return can work in a condition, but bool is the appropriate equality result.'],[
('What should operator== conventionally return?',['bool','Point*','void'],0,'Equality expresses a true/false relation.'),
('How many explicit operands does a binary member operator receive?',['Two','One, because the left operand is the calling object','Zero'],1,'The implicit calling object supplies the left operand.'),
('Can an overload change multiplication precedence?',['Yes','No','Only when returning a reference'],1,'C++ keeps the language’s operator precedence rules.')])
g('increment','Operator overloading, copies, and stream state.',
['Distinguish prefix and postfix results.','Use a dummy int to distinguish postfix syntax.','Preserve object state on failed extraction.'],[
('Prefix returns the updated object','For ++s, the operation updates the current object and conventionally returns Student& to it. The expression observes the new value. This avoids copying solely to represent the old value.'),
('Postfix returns the previous value','For s++, the operator saves a copy, updates the current object, and returns the saved value. The unnamed int parameter distinguishes postfix in the declaration; it is not an amount to add. In this example postfix delegates the update to prefix.'),
('Stream extraction should respect failure','operator>> reads into a temporary numeric value first. Only successful extraction changes the Student. It returns the input stream, allowing chaining and `if (cin>>s)` checks. This syntax demonstration does not impose the validated grade range used in the earlier mini-project.')],
['Starting at 65, s++ returns an old-value copy showing 65 and leaves s at 66.','++s updates s to 67 and returns the updated object.','Reading input 80 updates the stored grade; failed input leaves it unchanged.'],
[('Print s++ and then s on separate lines.','The displayed grades differ by one because postfix returns the earlier value.'),('Provide nonnumeric input to the extraction example.','The stream reports failure and the object is not updated from an uninitialized temporary.')],
['The postfix int parameter is a signature marker, not the increment amount.','Returning a reference to a local old-value copy would dangle.'],[
('Starting at 65, what value does s++ yield?',['65','66','67'],0,'Postfix yields the previous value, then the stored object has 66.'),
('What does prefix ++ conventionally return?',['A reference to the updated object','A reference to a local copy','A pointer to the stream'],0,'The updated original can be used in a chained expression.'),
('When should the extraction operator assign its temporary grade?',['Before reading','Only after successful extraction','Even if the stream failed'],1,'Failed reads must not overwrite the object with invalid temporary data.')])

for t in topics:
    if not t.get('model'):
        t['guide']=guides[t['id']]
        t['guide']['hint2']=t['exercise']['explanation']

# Every Point implementation should use double coordinates, including the operator example.
def doubles(code):
    if 'class Point' not in code:return code
    code=re.sub(r'\bfloat\b','double',code)
    code=code.replace('    int x, y;','    double x, y;').replace('Point(int initialX=0, int initialY=0)','Point(double initialX=0, double initialY=0)')
    for name in ['getX','getY']:code=code.replace('int '+name+'()', 'double '+name+'()')
    code=code.replace('setX(int value)','setX(double value)').replace('setY(int value)','setY(double value)').replace('moveBy(int dx, int dy)','moveBy(double dx, double dy)')
    return code
for e in examples:e['code']=doubles(e['code'])
for t in topics+optional:t['exercise']['solution']=doubles(t['exercise']['solution'])
basic=next(e for e in examples if e['id']=='point-basics')
basic['code']=basic['code'].replace('Point p1(2,3), p2;','Point p1(2.5,3.5), p2;').replace('p2.setX(8);','p2.setX(8.25);').replace('p1.moveBy(1,-1);','p1.moveBy(1.0,-1.0);')
model['predictionOutput']='(2.5,3.5)\n(0,0)\n(3.5,2.5)\n(8.25,0)'
steps=model['steps']
for s in steps:
    for o in s['objects']:
        if o['x']==2:o['x']=2.5
        if o['x']==8:o['x']=8.25
        if o['y']==3:o['y']=3.5
        if o['y']==7:o['y']=7.5
    s['code']=s['code'].replace('p1(2,3)','p1(2.5,3.5)').replace('setX(8)','setX(8.25)').replace('setY(7)','setY(7.5)')
    s['note']=s['note'].replace('(2,7)','(2.5,7.5)').replace('(2,3)','(2.5,3.5)').replace('(8,0)','(8.25,0)').replace('x becomes 8','x becomes 8.25')
model['steps'][5]['note']='The compiler-provided copy constructor copies this simple class’s double members into a new object.'
lesson=(root/'classes-lesson.html').read_text()
lesson=lesson.replace('The first examples use only integer coordinates','The Point examples use double coordinates so fractional positions are supported')
lesson=lesson.replace('int x, y;','double x, y;').replace('Point(int initialX=0, int initialY=0)','Point(double initialX=0, double initialY=0)').replace('int getX()','double getX()').replace('setX(int value)','setX(double value)')
lesson=lesson.replace('Point p1(2,3), p2;','Point p1(2.5,3.5), p2;').replace('p2.setX(8);','p2.setX(8.25);').replace('p1.moveBy(1,-1);','p1.moveBy(1.0,-1.0);')
lesson=lesson.replace('<pre>(2,3)\n(0,0)\n(3,2)\n(8,0)</pre>','<pre>'+model['predictionOutput']+'</pre>').replace('p1 from (2,3) to (3,2)','p1 from (2.5,3.5) to (3.5,2.5)')
lesson=lesson.replace('p1: (2,3)','p1: (2.5,3.5)').replace('p1 stays (2,3)','p1 stays (2.5,3.5)').replace('p2.x to 8: p2 becomes (8,0)','p2.x to 8.25: p2 becomes (8.25,0)').replace('p1.y to 7: p1 becomes (2,7)','p1.y to 7.5: p1 becomes (2.5,7.5)').replace('p3 is (2,7)','p3 is (2.5,7.5)').replace('(-1,7)','(-1,7.5)').replace('p1 stays (2,7)','p1 stays (2.5,7.5)').replace('p2 becomes (2,7)','p2 becomes (2.5,7.5)')
(root/'classes-lesson.html').write_text(lesson)
(root/'topics.json').write_text(json.dumps(topics,indent=2));(root/'content.json').write_text(json.dumps(examples,indent=2));(root/'optional.json').write_text(json.dumps(optional,indent=2));(root/'model.json').write_text(json.dumps(model,indent=2))
for e in examples:(root/'examples'/f"{e['id']}.cpp").write_text(e['code'])
for t in topics+optional:(root/'examples'/f"{t['exercise']['id']}.cpp").write_text(t['exercise']['solution'].strip()+'\n')
print(len(guides),'expanded lesson guides; Point coordinates use double')
