const fs=require('fs'),vm=require('vm'),assert=require('assert');
const {parseHTML}=require('linkedom');
const html=fs.readFileSync(__dirname+'/teaching/oop/index.html','utf8');
const {document,window}=parseHTML(html);window.location={hash:'#scope'};
const memory=new Map([['oop-v1-workspace-scope-code','// Old saved example\nvoid foo() {}']]);
const ctx={document,window,localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,String(v))},console,setTimeout,clearTimeout,AbortController,Blob,URL,Event:window.Event,navigator:{},confirm:()=>true};
vm.createContext(ctx);[...document.querySelectorAll('script')].forEach(s=>vm.runInContext(s.textContent,ctx));
const data=window.OOP_DATA;
for(const t of [...data.topics,...data.optional]){
 const workspace=document.querySelector(`[data-id="workspace-${t.id}"]`);
 assert(workspace);assert.equal(workspace.querySelector('.code-view').textContent,t.exercise.starter);
 assert.equal(workspace.dataset.source,'starter-'+t.id);
 if(t.guide){assert(t.guide.traceIntro);assert(t.guide.traceExample);assert(document.querySelector('#'+t.id+' .trace-preview code').textContent.length>0);}
}
assert.equal(document.querySelectorAll('.concept-intro').length,25);
const scope=document.querySelector('[data-id="workspace-scope"]');
assert(!scope.querySelector('.editor').value.includes('foo'));
assert(!scope.querySelector('.editor').value.includes('fun('));
assert(scope.querySelector('.previous-work').textContent.includes('void foo() {}'));
const editor=scope.querySelector('.editor');editor.value+='\n// learner edit';editor.dispatchEvent(new window.Event('input',{bubbles:true}));
assert(memory.get('oop-v1-workspace-scope-focused-v2-code').includes('learner edit'));
scope.querySelector('[data-action=reset]').click();assert.equal(editor.value,data.topics.find(t=>t.id==='scope').exercise.starter);
assert.equal(memory.get('oop-v1-workspace-scope-code'),'// Old saved example\nvoid foo() {}');
const arrays=data.topics.find(t=>t.id==='arrays');assert(arrays.answer.includes('{1, 2, 5, 0, 0}'));assert(!arrays.answer.includes('original document'));
const temperature=data.topics.find(t=>t.id==='temperature');assert.equal(temperature.title,'Const members - temperature conversion as a case study');assert(temperature.guide.exceptionCode.includes('catch'));assert(document.querySelector('#temperature-learn').textContent.includes('throw stops'));
const e15=data.examples.find(e=>e.id==='e15');assert(e15.code.includes('double bestDistance = points[0]'));assert(e15.code.includes('bestDistance = distance;'));
const download=document.querySelector('a[download="point-separated.zip"]');assert(download);assert(download.getAttribute('href').startsWith('data:application/zip;base64,'));
fs.writeFileSync('/tmp/oop-point-embedded.zip',Buffer.from(data.downloads[0].base64,'base64'));
assert(!document.querySelector('#visit-counter'));
assert(document.querySelector('#theme-toggle'));
console.log('PASS: 26 focused starters, all concept introductions and trace previews, old-work recovery, reset and persistence, arrays wording, temperature explanations, Point optimization, embedded ZIP, theme and dashboard-only analytics.');
