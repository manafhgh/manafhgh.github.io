// A two-state switch; follow the device until a student makes a choice.
(function () {
    const root = document.documentElement;
    const button = document.getElementById('theme-toggle');
    const preference = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
    let manual = false;
    try { manual = ['dark', 'light'].includes(localStorage.getItem('oop-theme')); } catch (_) {}
    function apply(theme) {
        root.setAttribute('data-theme', theme);
        const dark = theme === 'dark';
        const label = dark ? 'Switch to light mode' : 'Switch to dark mode';
        button.setAttribute('aria-label', label);
        button.setAttribute('title', label);
        button.setAttribute('aria-pressed', String(dark));
    }
    apply(root.getAttribute('data-theme') || 'light');
    button.addEventListener('click', function () {
        const theme = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        manual = true;
        apply(theme);
        try { localStorage.setItem('oop-theme', theme); } catch (_) {}
    });
    function deviceChanged(event) { if (!manual) apply(event.matches ? 'dark' : 'light'); }
    if (preference) {
        if (preference.addEventListener) preference.addEventListener('change', deviceChanged);
        else if (preference.addListener) preference.addListener(deviceChanged);
    }
})();
