// Dashboard-only visit tracking. Previews never send hits.
(function () {
    const host = 'https://manafhgh.goatcounter.com';
    const totalPath = '/teaching/oop/total';
    const topicPrefix = '/teaching/oop/topics/';
    const published = window.location.protocol === 'https:' &&
        ['manafhgh.com', 'www.manafhgh.com'].includes(window.location.hostname);
    const topics = new Map(DATA.topics.map(t => [t.id, t.title]));
    let previous = null, ready = false, failed = false;
    let queue = [];

    // These options are passed on EVERY hit: repeat reloads and returns count.
    function hit(path, title) {
        const item = {path, title, no_session: true, event: false, referrer: ''};
        if (ready) { try { window.goatcounter.count(item); } catch (_) {} }
        else if (!failed && queue.length < 100) queue.push(item);
    }
    function view(id) {
        const topic = topics.has(id);
        if (id !== previous && published) {
            hit(totalPath, 'OOP · Overall visits');
            if (topic) hit(topicPrefix + id, 'OOP · ' + topics.get(id));
        }
        previous = id;
    }
    window.oopVisitCounter = {view};
    if (published) {
        // No automatic pageview: it would duplicate the initial routed view.
        window.goatcounter = {no_onload: true, no_events: true, endpoint: host + '/count'};
        const script = document.createElement('script');
        script.src = 'https://gc.zgo.at/count.js';
        script.async = true;
        script.setAttribute('data-goatcounter', host + '/count');
        script.onload = function () {
            ready = typeof window.goatcounter.count === 'function';
            failed = !ready;
            const waiting = queue; queue = [];
            if (ready) waiting.forEach(item => { try { window.goatcounter.count(item); } catch (_) {} });
        };
        script.onerror = function () { failed = true; queue = []; };
        document.head.appendChild(script);
    }
    // Navigation was initialized before this file; record its resolved first view.
    view(currentLessonId);
})();
