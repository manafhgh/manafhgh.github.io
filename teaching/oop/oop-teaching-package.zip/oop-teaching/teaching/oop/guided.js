function prose(text) { return safe(text).replace(/`([^`]+)`/g,'<code>$1</code>'); }
function guidedLesson(t) {
    const g=t.guide,id=t.id;
    const quiz=g.quiz.map((q,n)=>`<fieldset class="quiz-question" data-guide-question="${n}"><legend>${n+1}. ${safe(q.prompt)}</legend>${q.options.map((o,i)=>`<label><input type="radio" name="${id}-q${n}" value="${i}" ${saved(id+'-q'+n,'')===String(i)?'checked':''}> ${safe(o)}</label>`).join('')}<p class="quiz-feedback" hidden></p></fieldset>`).join('');
    return `<div class="model-banner"><span class="eyebrow">Guided lesson · Study at your own pace</span><nav class="lesson-map" aria-label="${safe(t.title)} lesson"><a href="#${id}-learn">Learn</a><a href="#${id}-trace">Trace</a><a href="#${id}-predict">Predict</a><a href="#${id}-examples">Run</a><a href="#${id}-experiment">Experiment</a><a href="#${id}-practice">Practise</a><a href="#${id}-checkpoint">Checkpoint</a></nav></div>
    <div class="lesson-two-col"><div class="lesson-copy"><h3>Before you start</h3><p>${prose(g.prerequisites)}</p></div><div class="lesson-copy"><h3>Learning objectives</h3><ul>${g.goals.map(x=>`<li>${prose(x)}</li>`).join('')}</ul></div></div>
    <div class="lesson-copy" id="${id}-learn"><span class="eyebrow">1 · Learn</span>${g.sections.map(s=>`<h3>${safe(s.title)}</h3><p>${prose(s.text)}</p>`).join('')}${t.lesson?`<details class="answer"><summary>Additional reference notes</summary>${t.lesson}</details>`:''}</div>
    <div class="lesson-copy" id="${id}-trace"><span class="eyebrow">2 · Trace</span><h3>Follow the changing state</h3><ol>${g.trace.map(x=>`<li>${prose(x)}</li>`).join('')}</ol>${memoryPanel(t)}</div>
    <div class="lesson-copy" id="${id}-predict"><span class="eyebrow">3 · Predict</span><h3>Explain it before running</h3><p>${safe(t.question)}</p><label for="prediction-${id}">Your prediction or explanation</label><textarea id="prediction-${id}" class="prediction-input guide-prediction" data-lesson="${id}" rows="3" placeholder="Write your reasoning first">${safe(saved('prediction-'+id,''))}</textarea><details class="answer"><summary>Compare with the explanation</summary><p>${safe(t.answer)}</p></details></div>
    <div class="lesson-copy" id="${id}-examples"><span class="eyebrow">4 · Run and inspect</span><h3>Explore complete programs</h3><p>Predict an outcome, run the original, then change one statement at a time. Use Reset to restore the supplied program.</p></div>${examplesFor(t)}
    <div class="lesson-copy" id="${id}-experiment"><span class="eyebrow">5 · Experiment</span><h3>Change, observe, explain</h3><div class="experiment-grid">${g.experiments.map(x=>`<div><p>${prose(x.task)}</p><details class="answer"><summary>Expected observation</summary><p>${prose(x.answer)}</p></details></div>`).join('')}</div></div>
    <div class="lesson-copy" id="${id}-practice"><span class="eyebrow">6 · Practise</span>${practiceFor(t)}</div>
    <div class="lesson-copy" id="${id}-checkpoint"><span class="eyebrow">7 · Checkpoint</span><h3>Check the key ideas</h3><form class="guide-quiz" data-lesson="${id}">${quiz}<button class="primary" type="submit">Check my answers</button><button type="button" class="guide-reset">Reset questions</button><p class="guide-result" role="status"></p></form><div class="guide-mastery mastery-status" data-lesson="${id}"></div><h3>Common mistakes</h3><ul>${g.mistakes.map(x=>`<li>${prose(x)}</li>`).join('')}</ul></div>`;
}
function refreshGuideBadges() {
    document.querySelectorAll('.guide-mastery').forEach(el=>{
        const id=el.dataset.lesson;
        el.textContent=`Questions: ${saved('quiz-passed-'+id,'')==='yes'?'passed':'not yet passed'} · sample-output check: ${saved('sample-passed-'+id,'')==='yes'?'passed':'not yet passed'}. A matching sample is not a complete correctness proof.`;
    });
}
function setupGuides() {
    document.querySelectorAll('.guide-prediction').forEach(el=>el.addEventListener('input',()=>save('prediction-'+el.dataset.lesson,el.value)));
    document.querySelectorAll('.guide-quiz').forEach(form=>{
        const id=form.dataset.lesson,t=DATA.topics.find(x=>x.id===id);
        form.addEventListener('submit',event=>{
            event.preventDefault();let score=0;
            t.guide.quiz.forEach((q,n)=>{
                const selected=form.querySelector(`input[name="${id}-q${n}"]:checked`);
                const feedback=form.querySelector(`[data-guide-question="${n}"] .quiz-feedback`);
                const correct=selected && Number(selected.value)===q.correct;
                if(correct)score++;
                feedback.hidden=false;feedback.textContent=(correct?'Correct. ':selected?'Revisit this idea. ':'Choose an answer. ')+q.explanation;
                feedback.classList.toggle('correct',!!correct);
            });
            save('quiz-passed-'+id,score===t.guide.quiz.length?'yes':'');
            form.querySelector('.guide-result').textContent=`${score}/${t.guide.quiz.length} correct. ${score===t.guide.quiz.length?'Checkpoint passed.':'Read the explanations, revise your answers, and try again.'}`;
            refreshGuideBadges();
        });
        form.addEventListener('change',event=>{
            if(event.target.matches('input[type=radio]'))save(event.target.name,event.target.value);
            save('quiz-passed-'+id,'');form.querySelector('.guide-result').textContent='Selections changed. Check your answers again.';
            form.querySelectorAll('.quiz-feedback').forEach(x=>x.hidden=true);refreshGuideBadges();
        });
        form.querySelector('.guide-reset').addEventListener('click',()=>{
            form.querySelectorAll('input[type=radio]').forEach(x=>{x.checked=false;x.defaultChecked=false;save(x.name,'');});
            form.querySelectorAll('.quiz-feedback').forEach(x=>x.hidden=true);save('quiz-passed-'+id,'');form.querySelector('.guide-result').textContent='Questions reset.';refreshGuideBadges();
        });
    });
    refreshGuideBadges();
}
function normalizeOutput(text) { return String(text).trim().split(/\s+/).join(' '); }
function workspaceExercise(container) { return allLessons.find(t=>'workspace-'+t.id===container.dataset.id)?.exercise; }

let currentLessonId='revision';
function routeInfo(hash) {
    let anchor;try{anchor=decodeURIComponent((hash||'').replace(/^#/,''));}catch{anchor='revision';}
    if(!anchor||anchor==='revision')return {id:'revision',anchor:'revision'};
    if(anchor==='main')return {id:currentLessonId,anchor:'main'};
    if(anchor==='all')return {id:'all',anchor:'main'};
    const direct=DATA.topics.find(t=>t.id===anchor);if(direct)return {id:direct.id,anchor};
    const target=document.getElementById(anchor),parent=target?.closest('.topic');
    if(parent)return {id:parent.id,anchor};
    return {id:'revision',anchor:'revision',unknown:anchor};
}
function applyRoute(scroll=true) {
    const info=routeInfo(window.location.hash);currentLessonId=info.id;
    const all=info.id==='all',overview=info.id==='revision';
    DATA.topics.forEach(t=>document.getElementById(t.id).hidden=!all&&t.id!==info.id);
    const revisionLesson=DATA.topics.some(t=>t.id===info.id&&t.group==='revision');
    document.querySelector('#revision').hidden=!all&&!overview&&!revisionLesson;
    document.querySelector('#revision-overview').hidden=!all&&!overview;
    document.querySelector('#revision-overview').innerHTML=`<p>Select a sublesson below, or use the left navigation. Each lesson includes explanations, runnable programs, practice, and a checkpoint.</p><div class="revision-index">${DATA.topics.filter(t=>t.group==='revision').map(t=>`<a href="#${t.id}">${safe(t.title)}</a>`).join('')}</div>`;
    document.querySelectorAll('#topic-nav a').forEach(a=>{const active=a.getAttribute('href')==='#'+info.id;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
    const title=all?'All lessons':overview?'Revision':DATA.topics.find(t=>t.id===info.id).title;
    document.title=title+' | C++ OOP · Manaf Gharaibeh';
    document.querySelector('#view-all').textContent=all?'Return to Revision':'View all lessons';
    document.querySelector('#view-all').setAttribute('href',all?'#revision':'#all');
    const index=DATA.topics.findIndex(t=>t.id===info.id);
    const prev=index>0?DATA.topics[index-1]:null;
    const next=overview?DATA.topics[0]:index>=0&&index<DATA.topics.length-1?DATA.topics[index+1]:null;
    document.querySelector('#lesson-pagination').innerHTML=all?'':`<a href="${prev?'#'+prev.id:'#revision'}">← ${prev?safe(prev.title):'Revision overview'}</a>${next?`<a href="#${next.id}">${safe(next.title)} →</a>`:'<a href="#revision">Back to Revision →</a>'}`;
    if(info.anchor==='linked')document.querySelector('#linked').open=true;
    filterLessonSearch();
    window.oopVisitCounter?.view(info.id);
    if(scroll)document.getElementById(info.anchor)?.scrollIntoView?.({block:'start'});
}
function filterLessonSearch() {
    const q=document.querySelector('#search').value.trim().toLowerCase();let visible=0;
    DATA.topics.forEach(t=>{
        const searchable=[t.title,t.intro,t.question,t.exercise.task,t.lesson||'',JSON.stringify(t.guide||{}),t.model?DATA.model.html:'',...DATA.examples.filter(e=>e.topic===t.id).map(e=>e.code),t.id==='dynamic'?JSON.stringify(DATA.optional):''].join(' ').toLowerCase();
        const matches=!q||searchable.includes(q);
        document.querySelector(`#topic-nav a[data-topic="${t.id}"]`).hidden=!matches;
        if(matches)visible++;
        if(currentLessonId==='all')document.getElementById(t.id).hidden=!matches;
    });
    if(currentLessonId==='all')document.querySelector('#revision').hidden=!DATA.topics.some(t=>t.group==='revision'&&!document.getElementById(t.id).hidden);
    document.querySelector('#no-results').hidden=!q||visible>0;
    document.querySelector('#search-status').textContent=q?`${visible} matching lessons. Select a result in the navigation.`:'';
}
function setupNavigation() {
    window.addEventListener('hashchange',()=>applyRoute(true));
    document.querySelector('#search').addEventListener('input',filterLessonSearch);
    applyRoute(false);
}
