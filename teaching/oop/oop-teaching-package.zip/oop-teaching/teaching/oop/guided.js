function prose(text) { return safe(text).replace(/`([^`]+)`/g,'<code>$1</code>'); }
function tracePreview(t) {
    const guide=t.guide;
    if(guide.traceCode)return guide.traceCode;
    const example=DATA.examples.find(e=>e.id===guide.traceExample);
    if(!example)return '';
    const match=/int main\s*\([^)]*\)\s*\{/.exec(example.code);
    if(!match)return '';
    let depth=1, end=match.index+match[0].length;
    const start=end;
    while(depth&&end<example.code.length){if(example.code[end]==='{')depth++;if(example.code[end]==='}')depth--;end++;}
    const lines=example.code.slice(start,end-1).split('\n').filter(x=>x.trim()&&!x.trimStart().startsWith('//'));
    const indent=Math.min(...lines.map(line=>line.match(/^\s*/)[0].length));
    return lines.map(line=>line.slice(indent).trimEnd()).join('\n');
}
function projectDownloads(t) {
    return (DATA.downloads||[]).filter(d=>d.topic===t.id).map(d=>`<div class="project-download"><h4>Compile the separate files on your computer</h4><p>${safe(d.description)}</p><a class="view-switch" href="data:application/zip;base64,${safe(d.base64)}" download="${safe(d.filename)}">${safe(d.title)}</a>${d.command?`<pre class="lesson-code"><code>${safe(d.command)}</code></pre>`:''}<p class="footnote">${safe(d.footnote)}</p></div>`).join('');
}
function extraPracticeFor(t) {
    const x=t.extraPractice;
    if(!x)return '';
    return `<div class="practice"><h3>Coding practice (Part 2)</h3><h4>${safe(x.title)}</h4><p>${prose(x.intro)}</p>
    ${(x.notes||[]).map(n=>`<details class="answer"><summary>${safe(n.title)}</summary><p>${prose(n.text)}</p><pre class="lesson-code"><code>${safe(n.code)}</code></pre><p>${prose(n.after)}</p>${n.secondCode?`<pre class="lesson-code"><code>${safe(n.secondCode)}</code></pre><p>${prose(n.final)}</p>`:''}</details>`).join('')}
    ${x.items.map((ex,i)=>`<h4>${i+1}. ${safe(ex.title)}</h4><p>${prose(ex.task)}</p>
    ${ex.hint?`<details class="answer"><summary>Hint</summary><p>${prose(ex.hint)}</p></details>`: ''}<details class="example"><summary>Practice workspace</summary><div class="example-body">${runner(byId.get('starter-'+ex.id),'workspace-'+ex.id)}</div></details>
    <details class="solution"><summary>Reveal a worked solution</summary><p>${prose(ex.explanation)}</p>${runner(byId.get(ex.id),ex.id,true)}</details>`).join('')}
    ${x.quiz?`<h4>Check your understanding</h4><form class="extra-quiz" data-lesson="${t.id}-practice-extra">${x.quiz.map((q,n)=>`<fieldset class="quiz-question" data-guide-question="${n}"><legend>${n+1}. ${prose(q.prompt)}</legend>${q.options.map((o,i)=>`<label><input type="radio" name="${t.id}-practice-extra-q${n}" value="${i}" ${saved(t.id+'-practice-extra-q'+n,'')===String(i)?'checked':''}> ${'ABCD'[i]}. ${prose(o)}</label>`).join('')}<p class="quiz-feedback" hidden></p></fieldset>`).join('')}<button class="primary" type="submit">Check my answers</button><button type="button" class="guide-reset">Reset questions</button><p class="guide-result" role="status"></p></form>`:''}</div>`;
}
function dynamicWalkthrough() {
    return `<div class="lesson-copy"><h3>What survives a function call?</h3>
    <p>Watch the stack and heap as <code>main()</code> calls <code>foo()</code>. The recording is silent; the steps below describe what to look for.</p>
    <video controls playsinline preload="metadata" src="dynamic-memory.mp4" aria-label="Stack and heap walkthrough" style="width:100%;height:auto"><a href="dynamic-memory.mp4">Download the walkthrough</a></video>
    <p class="footnote">The memory visualization in this recording was created using <a href="https://pythontutor.com/" target="_blank" rel="noopener">Python Tutor</a>.</p>
    <ol>
    <li><strong>Before the call:</strong> Only <code>main()</code> is active. Once its declaration executes, <code>v</code> holds 5. The visualizer shows question marks for variables that have not been initialized. Neither array exists yet.</li>
    <li><strong>Inside <code>foo()</code>:</strong> Its frame appears alongside <code>main()</code>. The two <code>new[]</code> lines allocate separate four-element arrays. <code>delete[] ptr1</code> releases the first array.</li>
    <li><strong>Back in <code>main()</code>:</strong> The <code>foo()</code> frame disappears, but its second array survives. <code>p</code> receives its address. <code>ptr</code> walks through the elements; after the last increment it is one past the end and must not be dereferenced. <code>p</code> still holds the original address, so <code>delete[] p</code> releases the array.</li>
    </ol>
    <details class="answer"><summary>Tip: Stack frames, scope, and run-time sizes</summary>
    <p>A typical implementation reserves space for a function’s frame on entry and releases it on return. A local variable’s slot may already be reserved when execution reaches its declaration and initializes the variable. Scope determines where its name is usable; lifetime determines when the object exists. For example, <code>i</code> belongs to the loop even if its slot is part of the enclosing frame. C++ does not require every local to have a stack slot: a compiler can use registers, reuse slots, or omit unused variables.</p>
    <p><code>new[]</code> requests storage when executed. That allocation can outlive the function, and <code>delete[]</code> releases it. The allocator may reuse memory it already obtained from the operating system.</p>
    <p>GCC and Clang may accept <code>int a[n];</code> with a run-time <code>n</code> as an extension, typically reserving stack space at the declaration and releasing it at block exit. Standard C++ requires a compile-time bound for that declaration. For a run-time size, use <code>new int[n]</code> with <code>delete[]</code> in manual-allocation practice, or <code>std::vector&lt;int&gt;</code> for automatic cleanup.</p></details>
    <details class="answer"><summary>Tip: Tools for finding memory leaks</summary>
    <p>A program can print the correct output and still leak memory. If you’re interested, look up a tool for your operating system:</p>
    <ul><li>macOS: <code>leaks</code> or Xcode Instruments (Leaks)</li><li>Linux: Valgrind Memcheck or LeakSanitizer</li><li>Windows: Visual Studio’s CRT Debug Heap (<code>_CrtDumpMemoryLeaks</code>)</li></ul>
    <p>Try comparing the example with and without <code>delete[] p;</code>.</p></details></div>`;
}
function guidedLesson(t) {
    const g=t.guide,id=t.id;
    const quiz=g.quiz.map((q,n)=>`<fieldset class="quiz-question" data-guide-question="${n}"><legend>${n+1}. ${prose(q.prompt)}</legend>${q.options.map((o,i)=>`<label><input type="radio" name="${id}-q${n}" value="${i}" ${saved(id+'-q'+n,'')===String(i)?'checked':''}> ${prose(o)}</label>`).join('')}<p class="quiz-feedback" hidden></p></fieldset>`).join('');
    return `<div class="model-banner"><span class="eyebrow">Guided lesson · Study at your own pace</span><nav class="lesson-map" aria-label="${safe(t.title.replace(/`/g,''))} lesson"><a href="#${id}-learn">Learn</a><a href="#${id}-trace">Trace</a><a href="#${id}-predict">Predict</a><a href="#${id}-examples">Run</a><a href="#${id}-experiment">Experiment</a><a href="#${id}-practice">Practise</a><a href="#${id}-checkpoint">Checkpoint</a></nav></div>
    <div class="lesson-two-col"><div class="lesson-copy"><h3>Before you start</h3><p>${prose(g.prerequisites)}</p></div><div class="lesson-copy"><h3>Learning objectives</h3><ul>${g.goals.map(x=>`<li>${prose(x)}</li>`).join('')}</ul></div></div>
    <div class="lesson-copy" id="${id}-learn"><span class="eyebrow">1 · Learn</span>${g.sections.map(s=>`<h3>${prose(s.title)}</h3><p>${prose(s.text)}</p>${s.code?`<pre class="lesson-code"><code>${safe(s.code)}</code></pre>`:''}${s.after?`<p>${prose(s.after)}</p>`:''}${s.exampleCode?`<pre class="lesson-code"><code>${safe(s.exampleCode)}</code></pre>`:''}`).join('')}${g.exceptionCode?`<h4>Handling a rejected request</h4><p>This short block belongs inside main and uses the Temperature class defined in the complete program below. The catch parameter receives the string message, which you can print.</p><pre class="lesson-code"><code>${safe(g.exceptionCode)}</code></pre>`:''}${g.inputTip?`<details class="answer"><summary>${safe(g.inputTip.title)}</summary><p>${prose(g.inputTip.text)}</p><p>The main example uses:</p><pre class="lesson-code"><code>${safe(g.inputTip.code)}</code></pre><p>To check both input and range, replace those lines with:</p><pre class="lesson-code"><code>${safe(g.inputTip.replacement)}</code></pre><p>${prose(g.inputTip.after)}</p></details>`:''}${t.lesson?`<details class="answer"><summary>Additional reference notes</summary>${t.lesson}</details>`:''}</div>
    <div class="lesson-copy" id="${id}-trace"><span class="eyebrow">2 · Trace</span><h3>Follow the example step by step</h3><p>${prose(g.traceIntro)}</p><p class="footnote">Key lines from the program to follow. The complete runnable program appears in Run and inspect.</p><pre class="lesson-code trace-preview"><code>${safe(tracePreview(t))}</code></pre><ol>${g.trace.map(x=>`<li>${prose(x)}</li>`).join('')}</ol>${memoryPanel(t)}</div>
    <div class="lesson-copy" id="${id}-predict"><span class="eyebrow">3 · Predict</span><h3>Explain it before running</h3><p>${prose(t.question)}</p><label for="prediction-${id}">Your prediction or explanation</label><textarea id="prediction-${id}" class="prediction-input guide-prediction" data-lesson="${id}" rows="3" placeholder="Write your reasoning first">${safe(saved('prediction-'+id,''))}</textarea><details class="answer"><summary>Compare with the explanation</summary><p>${prose(t.answer)}</p></details></div>
    <div class="lesson-copy" id="${id}-examples"><span class="eyebrow">4 · Run and inspect</span><h3>Explore complete programs</h3><p>Predict an outcome, run the original, then change one statement at a time. Use Reset to restore the supplied program.</p></div>${examplesFor(t)}${projectDownloads(t)}${id==='dynamic'?dynamicWalkthrough():''}
    ${g.experimentNote?`<div class="lesson-copy"><details class="answer"><summary>${safe(g.experimentNote.title)}</summary><p>${prose(g.experimentNote.text)}</p><pre class="lesson-code"><code>${safe(g.experimentNote.code)}</code></pre><p>${prose(g.experimentNote.after)}</p></details></div>`:''}
    <div class="lesson-copy" id="${id}-experiment"><span class="eyebrow">5 · Experiment</span><h3>Change, observe, explain</h3><div class="experiment-grid">${g.experiments.map(x=>`<div><p>${prose(x.task)}</p><details class="answer"><summary>Expected observation</summary><p>${prose(x.answer)}</p></details></div>`).join('')}</div></div>
    <div class="lesson-copy" id="${id}-practice"><span class="eyebrow">6 · Practise</span>${practiceFor(t)}${extraPracticeFor(t)}</div>
    <div class="lesson-copy" id="${id}-checkpoint"><span class="eyebrow">7 · Checkpoint</span><h3>Check the key ideas</h3><form class="guide-quiz" data-lesson="${id}">${quiz}<button class="primary" type="submit">Check my answers</button><button type="button" class="guide-reset">Reset questions</button><p class="guide-result" role="status"></p></form><div class="guide-mastery mastery-status" data-lesson="${id}"></div><h3>Common mistakes</h3><ul>${g.mistakes.map(x=>`<li>${prose(x)}</li>`).join('')}</ul> ${g.endNote?`<h3>${safe(g.endNote.title)}</h3><p>${prose(g.endNote.text)}</p><pre class="lesson-code"><code>${safe(g.endNote.code)}</code></pre>`:''}</div>`;
}
function refreshGuideBadges() {
    document.querySelectorAll('.guide-mastery').forEach(el=>{
        const id=el.dataset.lesson;
        el.textContent=`Questions: ${saved('quiz-passed-'+id,'')==='yes'?'passed':'not yet passed'} · sample-output check: ${saved('sample-passed-'+id,'')==='yes'?'passed':'not yet passed'}. A matching sample is not a complete correctness proof.`;
    });
}
function setupGuides() {
    document.querySelectorAll('.guide-prediction').forEach(el=>el.addEventListener('input',()=>save('prediction-'+el.dataset.lesson,el.value)));
    document.querySelectorAll('.guide-quiz, .extra-quiz').forEach(form=>{
        const id=form.dataset.lesson, isExtra=id.endsWith('-practice-extra');
        const t=DATA.topics.find(x=>x.id===(isExtra?id.slice(0,-15):id));
        const questions=isExtra?t.extraPractice.quiz:t.guide.quiz;
        form.addEventListener('submit',event=>{
            event.preventDefault();let score=0;
            questions.forEach((q,n)=>{
                const selected=form.querySelector(`input[name="${id}-q${n}"]:checked`);
                const feedback=form.querySelector(`[data-guide-question="${n}"] .quiz-feedback`);
                const correct=selected && Number(selected.value)===q.correct;
                if(correct)score++;
                feedback.hidden=false;feedback.textContent=(correct?'Correct. ':selected?'Revisit this idea. ':'Choose an answer. ')+q.explanation.replace(/`/g,'');
                feedback.classList.toggle('correct',!!correct);
            });
            save('quiz-passed-'+id,score===questions.length?'yes':'');
            form.querySelector('.guide-result').textContent=`${score}/${questions.length} correct. ${score===questions.length?'Checkpoint passed.':'Read the explanations, revise your answers, and try again.'}`;
            refreshGuideBadges();
        });
        form.addEventListener('change',event=>{
            if(event.target.matches('input[type=radio]'))save(event.target.name,event.target.value);
            save('quiz-passed-'+id,'');form.querySelector('.guide-result').textContent='Selections changed. Check your answers again.';
            form.querySelectorAll('.quiz-feedback').forEach(x=>x.hidden=true);refreshGuideBadges();
        });
        form.querySelector('.guide-reset').addEventListener('click',()=>{
            form.querySelectorAll('input[type=radio]').forEach(x=>{x.checked=false;x.defaultChecked=false;save(x.name,'');});
            form.querySelectorAll('.quiz-feedback').forEach(x=>x.hidden=true);save('quiz-passed-'+id,'');form.querySelector('.guide-result').textContent='Questions reset.';refreshGuideBadges();
        });
    });
    refreshGuideBadges();
}
function normalizeOutput(text) { return String(text).trim().split(/\s+/).join(' '); }
function workspaceExercise(container) { return allLessons.find(t=>'workspace-'+t.id===container.dataset.id)?.exercise; }

let currentLessonId='revision';
function routeInfo(hash) {
    let anchor;try{anchor=decodeURIComponent((hash||'').replace(/^#/,''));}catch{anchor='revision';}
    if(!anchor||anchor==='revision')return {id:'revision',anchor:'revision'};
    if(anchor==='main')return {id:currentLessonId,anchor:'main'};
    if(anchor==='all')return {id:'all',anchor:'main'};
    const direct=DATA.topics.find(t=>t.id===anchor);if(direct)return {id:direct.id,anchor};
    const target=document.getElementById(anchor),parent=target?.closest('.topic');
    if(parent)return {id:parent.id,anchor};
    return {id:'revision',anchor:'revision',unknown:anchor};
}
function applyRoute(scroll=true) {
    const info=routeInfo(window.location.hash);currentLessonId=info.id;
    const all=info.id==='all',overview=info.id==='revision';
    DATA.topics.forEach(t=>document.getElementById(t.id).hidden=!all&&t.id!==info.id);
    const revisionLesson=DATA.topics.some(t=>t.id===info.id&&t.group==='revision');
    document.querySelector('#revision').hidden=!all&&!overview&&!revisionLesson;
    document.querySelector('#revision-overview').hidden=!all&&!overview;
    document.querySelector('#revision-overview').innerHTML=`<p>Select a sublesson below, or use the left navigation. Each lesson includes explanations, runnable programs, practice, and a checkpoint.</p><div class="revision-index">${DATA.topics.filter(t=>t.group==='revision').map(t=>`<a href="#${t.id}">${safe(t.title)}</a>`).join('')}</div>`;
    document.querySelectorAll('#topic-nav a').forEach(a=>{const active=a.getAttribute('href')==='#'+info.id;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
    const title=all?'All lessons':overview?'Revision':DATA.topics.find(t=>t.id===info.id).title;
    document.title=title.replace(/`/g,'')+' | C++ OOP · Manaf Gharaibeh';
    document.querySelector('#view-all').textContent=all?'Return to Revision':'View all lessons';
    document.querySelector('#view-all').setAttribute('href',all?'#revision':'#all');
    const index=DATA.topics.findIndex(t=>t.id===info.id);
    const prev=index>0?DATA.topics[index-1]:null;
    const next=overview?DATA.topics[0]:index>=0&&index<DATA.topics.length-1?DATA.topics[index+1]:null;
    document.querySelector('#lesson-pagination').innerHTML=all?'':`<a href="${prev?'#'+prev.id:'#revision'}">← ${prev?prose(prev.title):'Revision overview'}</a>${next?`<a href="#${next.id}">${prose(next.title)} →</a>`:'<a href="#revision">Back to Revision →</a>'}`;
    if(info.anchor==='linked')document.querySelector('#linked').open=true;
    filterLessonSearch();
    window.oopVisitCounter?.view(info.id);
    if(scroll)document.getElementById(info.anchor)?.scrollIntoView?.({block:'start'});
}
function filterLessonSearch() {
    const q=document.querySelector('#search').value.trim().toLowerCase();let visible=0;
    DATA.topics.forEach(t=>{
        const searchable=[t.title,t.intro,t.question,t.exercise.task,t.lesson||'',JSON.stringify(t.guide||{}),t.model?DATA.model.html:'',...DATA.examples.filter(e=>e.topic===t.id).map(e=>e.code),t.id==='dynamic'?JSON.stringify(DATA.optional):''].join(' ').toLowerCase();
        const matches=!q||searchable.includes(q);
        document.querySelector(`#topic-nav a[data-topic="${t.id}"]`).hidden=!matches;
        if(matches)visible++;
        if(currentLessonId==='all')document.getElementById(t.id).hidden=!matches;
    });
    if(currentLessonId==='all')document.querySelector('#revision').hidden=!DATA.topics.some(t=>t.group==='revision'&&!document.getElementById(t.id).hidden);
    document.querySelector('#no-results').hidden=!q||visible>0;
    document.querySelector('#search-status').textContent=q?`${visible} matching lessons. Select a result in the navigation.`:'';
}
function setupNavigation() {
    window.addEventListener('hashchange',()=>applyRoute(true));
    document.querySelector('#search').addEventListener('input',filterLessonSearch);
    applyRoute(false);
}
