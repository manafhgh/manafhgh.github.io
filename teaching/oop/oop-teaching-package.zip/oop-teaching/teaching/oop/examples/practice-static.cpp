#include <iostream>
class Box {
    static int count;
public:
    Box() { ++count; }
    Box(const Box&) { ++count; }
    ~Box() { --count; }
    static int getCount() { return count; }
};
int Box::count = 0;
int main() {
    std::cout << Box::getCount() << '\n';
    {
        Box a;
        Box b(a);
        std::cout << Box::getCount() << '\n';
    }
    std::cout << Box::getCount() << '\n';
}
