#include <iostream>
int nextId() {
    // TODO: retain a counter between calls and return its next value.
    return 0; // Replace this placeholder.
}
int main() {
    std::cout << nextId() << ' ' << nextId() << ' ' << nextId() << '\n';
}
