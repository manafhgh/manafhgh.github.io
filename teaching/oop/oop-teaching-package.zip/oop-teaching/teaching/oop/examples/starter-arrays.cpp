#include <iostream>
int countEven(const int values[], int size) {
    // TODO: stop at an empty range; otherwise inspect one element and recurse.
    (void)values; (void)size;
    return 0; // Replace this placeholder.
}
int main() {
    const int values[5] = {1, 2, 5, 0, 0};
    std::cout << countEven(values, 5) << '\n';
}
