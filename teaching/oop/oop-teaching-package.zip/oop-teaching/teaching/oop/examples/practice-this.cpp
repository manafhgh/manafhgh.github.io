#include <iostream>
class A {
    int x = 5;
public:
    A& add(int amount) {
        x += amount;
        return *this;
    }
    void print() const { std::cout << x << '\n'; }
};
int main() {
    A a;
    a.add(10).add(20);
    a.print();
}
