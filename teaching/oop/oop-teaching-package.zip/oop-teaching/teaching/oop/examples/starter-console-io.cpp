#include <iostream>
#include <iomanip>
int main() {
    // TODO: read two numeric grades.
    // TODO: reject failed input or grades outside [0, 100].
    // TODO: print "Average: " and the average with one decimal place.
}
