#include <iostream>
#include <cmath>
class Point {
    double x, y;
public:
    Point(double xx = 0, double yy = 0) : x(xx), y(yy) {}
    double distanceMember(const Point& other) const {
        const double dx = other.x - x, dy = other.y - y;
        return std::sqrt(dx * dx + dy * dy);
    }
    double distanceToOrigin() const {
        // TODO: return this point's distance from (0, 0).
        return 0;
    }
};
int main() {
    Point a(3, 4), b;
    std::cout << a.distanceToOrigin() << ' ' << b.distanceToOrigin() << '\n';
}
