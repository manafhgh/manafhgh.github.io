#include <iostream>
using namespace std;
class Point {
private:
    double x, y;
public:
    Point(double initialX=0, double initialY=0) : x(initialX), y(initialY) {}
    double getX() const { return x; }
    double getY() const { return y; }
    void setX(double value) { x=value; }
    void setY(double value) { y=value; }
    void moveBy(double dx, double dy) { x+=dx; y+=dy; }
    void print() const { cout << '(' << x << ',' << y << ")\n"; }
};
int main() {
    Point p1(2.5,3.5), p2;
    p1.print();
    p2.print();
    p2.setX(8.25);
    p1.moveBy(1.0,-1.0);
    p1.print();
    p2.print();
    return 0;
}
