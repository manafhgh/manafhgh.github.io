#include <iostream>
class Box {
    static int count;
public:
    Box() { ++count; }
    Box(const Box&) { ++count; }
    ~Box() { --count; }
    static int getCount() { return count; }
};
int Box::count = 0;
int main() {
    std::cout << Box::getCount() << '\n';
    {
        // TODO: construct two Boxes here and print the live count.
    }
    std::cout << Box::getCount() << '\n';
}
