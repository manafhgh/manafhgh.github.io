#include <iostream>
#include <string>
using namespace std;
class Student {
    int numberOfGrades;
    double* grades;
public:
    Student(int n=3) : numberOfGrades(n), grades(nullptr) {
        if (n <= 0) throw string("Grade count must be positive");
        grades = new double[n]{};
    }
    ~Student() { delete[] grades; }
    Student(const Student& other) : Student(other.numberOfGrades) {
        for (int i = 0; i < numberOfGrades; ++i) {
            grades[i] = other.grades[i];
        }
    }
    // This function overloads the assignment operator (=).
    // You do not need to implement it for this lesson.
    // We will cover it later when we study operator overloading.
    Student& operator=(const Student& other) {
        if (this != &other) {
            // Allocate first: if allocation fails, this object's data survives.
            double* replacement = new double[other.numberOfGrades];
            for (int i = 0; i < other.numberOfGrades; ++i) {
                replacement[i] = other.grades[i];
            }
            delete[] grades;
            grades = replacement;
            numberOfGrades = other.numberOfGrades;
        }
        return *this;
    }
    // Assumes the input contains enough numeric grades.
    void setGrades() {
        for (int i=0; i<numberOfGrades; ++i) {
            double value = 0.0;
            cin >> value;
            if (value < 0 || value > 100)
                throw string("Expected a grade between 0 and 100");
            grades[i] = value;
        }
    }
    void changeGrade(double delta, int index) {
        if (index < 0 || index >= numberOfGrades) throw string("Grade index");
        double value = grades[index] + delta;
        if (!(value >= 0 && value <= 100)) throw string("Grade range");
        grades[index] = value;
    }
    double avg() const {
        double total=0;
        for (int i=0; i<numberOfGrades; ++i) total += grades[i];
        return total / numberOfGrades;
    }
    void printStudent() const {
        for (int i=0; i<numberOfGrades; ++i) cout << grades[i] << ' ';
        cout << "average: " << avg() << '\n';
    }
};
int main() {
    try {
        Student a(3);
        a.setGrades(); // Enter all three grades in the input box before Run.
        Student b(a); // Deep copy: b owns a separate array.
        b.changeGrade(5,0);
        Student c;
        c = a; // Deep-copy assignment, not copy construction.
        a.printStudent(); b.printStudent(); c.printStudent();
    } catch (const string& message) {
        cerr << message << '\n';
        return 1;
    }
}
