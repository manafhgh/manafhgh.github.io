#include <iostream>
int nextId() {
    static int counter = 0;
    return ++counter;
}
int main() {
    std::cout << nextId() << ' ' << nextId() << ' ' << nextId() << '\n';
}
