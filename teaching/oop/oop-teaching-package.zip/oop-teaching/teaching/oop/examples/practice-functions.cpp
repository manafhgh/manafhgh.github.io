#include <iostream>
void increment(int& value) {
    ++value;
}
int main() {
    int x = 5;
    increment(x);
    increment(x);
    std::cout << x << '\n';
}
