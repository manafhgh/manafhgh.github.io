#include <iostream>
#include <string>

using std::cout;
using std::string;

class IntArrayList {
private:
    int size;
    int capacity;
    int* data;

public:
    IntArrayList(int initialCapacity = 2)
        : size(0), capacity(initialCapacity), data(nullptr)
    {
        if (initialCapacity <= 0)
            throw string("Capacity must be positive");
        data = new int[capacity];
    }
    ~IntArrayList() { delete[] data; }

    // This exercise uses one list; copying is disabled.
    IntArrayList(const IntArrayList&) = delete;
    IntArrayList& operator=(const IntArrayList&) = delete;

    void add(int /* value */) {
        // TODO: Name the parameter value, grow if full, and append.
    }

    int getSize() const { /* TODO */ return 0; }
    int getCapacity() const { return capacity; }

    double average() const {
        if (size == 0)
            throw string("Cannot average an empty list");
        // TODO: Compute the average of stored elements.
        return 0.0;
    }

    void print() const {
        for (int i = 0; i < size; ++i) {
            if (i != 0) cout << ' ';
            cout << data[i];
        }
        cout << '\n';
    }
};

int main() {
    IntArrayList values(2);
    try {
        values.average();
    } catch (const string& message) {
        cout << message << '\n';
    }

    for (int value = 10; value <= 50; value += 10)
        values.add(value);
    values.print();
    cout << "Size: " << values.getSize() << '\n';
    cout << "Capacity: " << values.getCapacity() << '\n';
    if (values.getSize() != 0)
        cout << "Average: " << values.average() << '\n';
}
