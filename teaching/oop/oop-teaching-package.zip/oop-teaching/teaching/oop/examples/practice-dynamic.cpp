#include <iostream>
class Point {
    double x, y;
public:
    Point(double xx = 0, double yy = 0) : x(xx), y(yy) {}
    void printPoint() const { std::cout << '(' << x << ',' << y << ")\n"; }
};
int main() {
    Point* points = new Point[3]{{1,1}, {2,2}, {3,3}};
    for (int i = 0; i < 3; ++i) points[i].printPoint();
    delete[] points;
    points = nullptr;
}
