#include <iostream>
class Point {
    double x, y;
public:
    Point(double xx = 0, double yy = 0) : x(xx), y(yy) {}
    void printPoint() const { std::cout << '(' << x << ',' << y << ")\n"; }
};
int main() {
    // TODO: allocate three Points with coordinates (1,1), (2,2), (3,3).
    // TODO: print them, then release the array with the matching delete form.
}
