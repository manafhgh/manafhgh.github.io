#include <iostream>

using std::cout;

class Student {
    int numberOfGrades;
    double* grades;

public:
    Student(int n = 3) : numberOfGrades(n), grades(new double[n]{}) {}
    ~Student() { delete[] grades; }

    Student(const Student& other) : Student(other.numberOfGrades) {
        // TODO: Copy the grades into the new array.
    }

    void setGrade(int i, double grade) { grades[i] = grade; }
    double getGrade(int i) const { return grades[i]; }
};

int main() {
    Student original;
    original.setGrade(0, 70);
    original.setGrade(1, 80);
    original.setGrade(2, 90);
    Student copy(original);
    copy.setGrade(0, 75);

    for (int i = 0; i < 3; ++i)
        cout << original.getGrade(i) << ' ' << copy.getGrade(i) << '\n';
}
