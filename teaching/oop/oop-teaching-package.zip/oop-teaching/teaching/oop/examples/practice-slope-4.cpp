#include <iostream>
#include <string>

using std::cout;
using std::string;

class Point {
    friend class Line;

private:
    double x, y;

public:
    Point(double x, double y) : x(x), y(y) {}

};

class Line {
    Point start, end;

public:
    Line(const Point& a, const Point& b) : start(a), end(b) {}
    double slope() const;
};

double Line::slope() const {
    const double dx = end.x - start.x;
    if (dx == 0.0)
        throw string("Vertical line: undefined slope");
    return (end.y - start.y) / dx;
}

void showSlope(const Line& line) {
    try {
        const double result = line.slope();
        cout << result << '\n';
    } catch (const string& message) {
        cout << message << '\n';
    }
}

int main() {
    const Point a(1, 2), b(4, 8), c(4, 2), d(1, 8);
    showSlope(Line(a, b));
    showSlope(Line(a, c));
    showSlope(Line(a, d));
}
