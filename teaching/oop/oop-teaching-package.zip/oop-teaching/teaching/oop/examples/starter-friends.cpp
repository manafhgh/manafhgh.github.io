
#include <iostream>
using namespace std;

class ClassB;

class ClassA {
   public:
      // constructor to initialize numA to 500
      ClassA() : numA(500) {}
    
  private:
      int numA;
    
  // friend function declaration
  // can be placed anywhere in the class
  // it would still mean the same
  friend int multiply(const ClassA &, const ClassB &);
};

class ClassB {

  public:
      // constructor to initialize numB to 166
      ClassB() : numB(166) {}
   private:
      int numB;
      // friend function declaration
      friend int multiply(const ClassA &, const ClassB &); 
};

int multiply(const ClassA& objectA, const ClassB& objectB) {
    // TODO: use friendship to multiply the two private numbers.
    (void)objectA; (void)objectB;
    return 0;
}

int main() {
  ClassA objectA;
  ClassB objectB;
  cout << "Product: " << multiply(objectA, objectB) << endl;
  return 0;
}
