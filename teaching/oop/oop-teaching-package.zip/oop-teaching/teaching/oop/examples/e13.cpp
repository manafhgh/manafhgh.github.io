// point.h: the interface

class Point {
private:
    double x;
    double y;
public:
    // With no arguments, construct the origin (0,0).
    Point(double xx = 0, double yy = 0);
    Point(const Point& other);
    ~Point();

    void setX(double value);
    void setY(double value);
    double getX() const;
    double getY() const;
    void printPoint() const;
    int whichQuadrant() const;
    double distanceMember(const Point& other) const;
};

// point.cpp: member definitions
#include <cmath>
#include <iostream>

Point::Point(double xx, double yy) : x(xx), y(yy) {}

Point::Point(const Point& other) : x(other.x), y(other.y) {
    std::cout << "Copy constructor: ";
    printPoint();
}

Point::~Point() = default;
void Point::setX(double value) { x = value; }
void Point::setY(double value) { y = value; }
double Point::getX() const { return x; }
double Point::getY() const { return y; }
void Point::printPoint() const { std::cout << '(' << x << ',' << y << ")\n"; }

int Point::whichQuadrant() const {
    if (x > 0 && y > 0) return 1;
    if (x < 0 && y > 0) return 2;
    if (x < 0 && y < 0) return 3;
    if (x > 0 && y < 0) return 4;
    return -1; // A point on either axis, including the origin, has no quadrant.
}

double Point::distanceMember(const Point& other) const {
    const double dx = other.x - x;
    const double dy = other.y - y;
    return std::sqrt(dx * dx + dy * dy);
}

// driver.cpp: non-member functions and main
#include <cmath>
#include <iostream>

// The non-member version reads both points through their public interface.
double distance(const Point& a, const Point& b) {
    const double dx = b.getX() - a.getX();
    const double dy = b.getY() - a.getY();
    return std::sqrt(dx * dx + dy * dy);
}

Point closestToOrigin(const Point points[], int size) {
    // Precondition: size > 0 and points contains at least size elements.
    const Point origin(0, 0);
    int best = 0;
    double bestDistance = points[0].distanceMember(origin);
    for (int i = 1; i < size; ++i) {
        const double distance = points[i].distanceMember(origin);
        if (distance < bestDistance) {
            best = i;
            bestDistance = distance;
        }
    }
    std::cout << "Address of selected array element: " << &points[best] << '\n';
    return points[best]; // A value, not a reference to an array element.
}

int main() {
    Point p1(1, 2), p2;
    p1.printPoint();
    p2.printPoint();

    Point points[5] = {{3,5}, {5,3}, {1,0}, {6,6}, {7,8}};
    points[4].setX(20);
    Point closest = closestToOrigin(points, 5);
    std::cout << "Address of returned object: " << &closest << '\n';
    std::cout << "Address of points[2]: " << &points[2] << '\n';
    std::cout << "Closest point: ";
    closest.printPoint();
}
