#include <iostream>
#include <cmath>
class Point {
    double x, y;
public:
    Point(double xx = 0, double yy = 0) : x(xx), y(yy) {}
    double distanceMember(const Point& other) const {
        const double dx = other.x - x, dy = other.y - y;
        return std::sqrt(dx * dx + dy * dy);
    }
    void setX(double value) { x = value; }
    void setY(double value) { y = value; }
};
class Line {
    Point start, end;
public:
    Line(const Point& a, const Point& b) : start(a), end(b) {}
    double length() const { return start.distanceMember(end); }
};
int main() {
    Point a(0, 0), b(3, 4);
    Line line(a, b);
    std::cout << line.length() << '\n';
    b.setX(6); b.setY(8);
    std::cout << line.length() << '\n';
}
