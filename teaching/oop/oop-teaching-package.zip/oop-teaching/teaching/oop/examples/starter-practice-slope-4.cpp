#include <iostream>
#include <string>

using std::cout;
using std::string;

class Point {
    // TODO: grant friendship to Line.

private:
    double x, y;

public:
    Point(double x, double y) : x(x), y(y) {}
    double getX() const { return x; }
    double getY() const { return y; }
};

class Line {
    Point start, end;

public:
    Line(const Point& a, const Point& b) : start(a), end(b) {}
    double slope() const;
};

double Line::slope() const {
    // TODO: compute the slope and handle a vertical line.
    return 0.0;
}

void showSlope(const Line& line) {
    try {
        const double result = line.slope();
        cout << result << '\n';
    } catch (const string& message) {
        cout << message << '\n';
    }
}

int main() {
    const Point a(1, 2), b(4, 8), c(4, 2), d(1, 8);
    showSlope(Line(a, b));
    showSlope(Line(a, c));
    showSlope(Line(a, d));
}
