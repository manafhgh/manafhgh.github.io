#include <iostream>
#include <string>
using namespace std;
class Student {
    string name;
    double grade;
public:
    Student(string n, double g=0) : name(n), grade(g) {}
    Student& operator--() {
        // TODO: decrease grade and return the updated object by reference.
        return *this;
    }
    Student operator--(int) {
        // TODO: save the old value, decrease this object, return the saved value.
        return *this; // Placeholder: returns a value, not the old value yet.
    }
    Student& operator++() { ++grade; return *this; } // Prefix.
    Student operator++(int) { // Postfix: unnamed dummy int distinguishes it.
        Student old(*this);
        ++(*this);
        return old;
    }
    friend ostream& operator<<(ostream& out, const Student& s) {
        return out << s.name << ' ' << s.grade;
    }

};

int main() {
    Student s("Hazem",65);
    cout << s-- << "\n" << s << "\n";
    cout << --s << "\n";
}
