#include <iostream>

#define SIZE 4

int* foo() {
    int* ptr1 = new int[SIZE]{3, 6, 9};
    int* ptr2 = new int[SIZE]{3, 6, 9};
    delete[] ptr1;
    return ptr2;
}

int main() {
    [[maybe_unused]] int v = 5; // Visible in the memory walkthrough.
    int* p = foo();
    int* ptr = p;
    for (int i = 0; i < SIZE; ++i) {
        std::cout << *ptr << " ";
        ++ptr;
    }
    delete[] p;
    return 0;
}
