#include <iostream>
class Point {
    double x, y;
public:
    Point(double xx, double yy) : x(xx), y(yy) {
        std::cout << "Construct "; printPoint();
    }
    ~Point() { std::cout << "Destroy "; printPoint(); }
    void printPoint() const { std::cout << '(' << x << ',' << y << ")\n"; }
};
int main() {
    Point outer(1, 1);
    {
        Point inner(2, 2);
    }
    std::cout << "Back in outer scope\n";
}
