#include <iostream>
int main() {
    int x = 42, y = 10;
    // TODO: declare p as a const pointer to const int, pointing at x.
    // TODO: print *p and y on one line.
    // TODO: write the two forbidden assignments as comments.
    (void)x; (void)y;
}
