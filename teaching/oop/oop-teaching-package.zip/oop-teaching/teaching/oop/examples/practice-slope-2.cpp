#include <iostream>
#include <string>

using std::cout;
using std::string;

class Point {
private:
    double x, y;

public:
    Point(double x, double y) : x(x), y(y) {}
    double getX() const { return x; }
    double getY() const { return y; }
};

class Line {
    Point start, end;
    friend double slope(const Line& line);

public:
    Line(const Point& a, const Point& b) : start(a), end(b) {}

};

double slope(const Line& line) {
    const double dx = line.end.getX() - line.start.getX();
    if (dx == 0.0)
        throw string("Vertical line: undefined slope");
    return (line.end.getY() - line.start.getY()) / dx;
}

void showSlope(const Line& line) {
    try {
        const double result = slope(line);
        cout << result << '\n';
    } catch (const string& message) {
        cout << message << '\n';
    }
}

int main() {
    const Point a(1, 2), b(4, 8), c(4, 2), d(1, 8);
    showSlope(Line(a, b));
    showSlope(Line(a, c));
    showSlope(Line(a, d));
}
