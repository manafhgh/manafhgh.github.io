#include <iostream>
void increment(int& value) {
    // TODO: increase the caller's value by one.
    (void)value;
}
int main() {
    int x = 5;
    increment(x);
    increment(x);
    std::cout << x << '\n';
}
