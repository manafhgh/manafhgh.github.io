#include <iostream>
class Point {
    double x, y;
public:
    Point(double xx, double yy) : x(xx), y(yy) {
        std::cout << "Construct "; printPoint();
    }
    ~Point() { std::cout << "Destroy "; printPoint(); }
    void printPoint() const { std::cout << '(' << x << ',' << y << ")\n"; }
};
int main() {
    // TODO: construct outer(1, 1) here.
    {
        // TODO: construct inner(2, 2) in this block.
    }
    std::cout << "Back in outer scope\n";
}
