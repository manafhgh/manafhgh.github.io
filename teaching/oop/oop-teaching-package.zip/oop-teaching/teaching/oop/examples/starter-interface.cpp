#include <iostream>
// Interface: these declarations normally go in point.h.
class Point {
    double x, y;
public:
    Point(double xx = 0, double yy = 0);
    double getX() const;
};
// Implementation: these definitions normally go in point.cpp.
Point::Point(double xx, double yy) : x(xx), y(yy) {}
double Point::getX() const {
    // TODO: return the x coordinate. Keep the declaration and definition consistent.
    return 0;
}
// Driver: this normally goes in main.cpp.
int main() {
    Point p(3, 4);
    std::cout << p.getX() << '\n';
}
