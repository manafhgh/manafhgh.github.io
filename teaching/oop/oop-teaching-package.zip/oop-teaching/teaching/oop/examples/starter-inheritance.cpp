#include <iostream>
#include <string>
class Student {
    std::string first, last, id;
public:
    Student(std::string fn, std::string ln, std::string number) : first(fn), last(ln), id(number) {
        std::cout << "Base const.\n";
    }
    void print() const { std::cout << id << ' ' << first << ' ' << last << '\n'; }
    virtual ~Student() { std::cout << "Base DEST\n"; }
};
class UnderGrad : public Student {
    std::string trainingCompany;
    // TODO: add a graduationYear data member.
public:
    UnderGrad(std::string company, std::string fn, std::string ln, std::string id, int year)
        : Student(fn, ln, id), trainingCompany(company) {
        (void)year; // TODO: store year in the new member.
        std::cout << "Derived const.\n";
    }
    void print() const {
        Student::print();
        std::cout << trainingCompany << '\n';
        // TODO: print graduationYear on the next line.
    }
    ~UnderGrad() { std::cout << "Derived DEST\n"; }
};
int main() {
    UnderGrad student("ABC", "Leila", "Ali", "123", 2027);
    student.print();
}
