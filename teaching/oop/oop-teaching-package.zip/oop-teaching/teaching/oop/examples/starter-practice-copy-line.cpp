#include <iostream>
#include <string>

using std::cout;
using std::string;

class Point {
private:
    double x, y;

public:
    Point(double x, double y) : x(x), y(y) {}
    void print() const { cout << '(' << x << ", " << y << ')'; }
};

class Line {
    // Composition: a Line contains two Point objects.
    Point start;  // By-value member
    Point end;    // By-value member
public:
    Line(const Point& a, const Point& b) : start(a), end(b) {}
    Line(const Line&) = default; // TODO: write an initializer list.
    Point getStart() const { return Point(0, 0); } // TODO
    Point getEnd() const { return Point(0, 0); }   // TODO
    void setStart(const Point& p) { start = p; }
};

void show(const string& label, const Line& line) {
    cout << label;
    line.getStart().print();
    cout << " to ";
    line.getEnd().print();
    cout << '\n';
}

int main() {
    Line original(Point(1, 2), Point(4, 8));
    Line copy(original);
    copy.setStart(Point(9, 9));
    show("Original: ", original);
    show("Copy: ", copy);
}
