#include <iostream>
#include <string>

using std::string;
class Temperature {
    const char scale;
    double reading;
public:
    Temperature(char unit, double value) : scale(unit), reading(value) {
        if (unit != 'C' && unit != 'F') throw string("Use C or F");
    }
    double celsius() const { return scale == 'C' ? reading : (reading - 32) * 5.0 / 9.0; }
    void changeT(char unit, double change) {
        if (unit != 'C' && unit != 'F') throw string("Use C or F");
        if (unit == scale) reading += change;
        else reading += scale == 'C' ? change * 5.0 / 9.0 : change * 9.0 / 5.0;
    }
    void printT() const {
        std::cout << celsius() << " C\n";
        std::cout << (scale == 'F' ? reading : reading * 9.0 / 5.0 + 32) << " F\n";
    }
};
double tempAvgArray(const Temperature values[], int size) {
    if (size <= 0) throw string("Average requires a nonempty array");
    double total = 0;
    for (int i = 0; i < size; ++i) total += values[i].celsius();
    return total / size;
}
int main() {
    Temperature values[2] = {Temperature('C', 0), Temperature('F', 32)};
    // TODO: increase values[0] by 18 Fahrenheit degrees.
    // TODO: increase values[1] by 10 Celsius degrees.
    for (int i = 0; i < 2; ++i) {
        std::cout << '[' << i << "]\n";
        values[i].printT();
        std::cout << "-------\n";
    }
    std::cout << "-------\n" << tempAvgArray(values, 2) << " C\n";
}
