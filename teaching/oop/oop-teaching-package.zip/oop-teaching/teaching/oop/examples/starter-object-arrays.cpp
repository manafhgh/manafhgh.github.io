#include <iostream>
#include <cmath>
class Point {
    double x, y;
public:
    Point(double xx = 0, double yy = 0) : x(xx), y(yy) {}
    double distanceMember(const Point& other) const {
        const double dx = other.x - x, dy = other.y - y;
        return std::sqrt(dx * dx + dy * dy);
    }
    void printPoint() const { std::cout << '(' << x << ',' << y << ")\n"; }
};
Point closestToOrigin(const Point points[], int size) {
    // Precondition: size > 0 and points contains at least size elements.
    const Point origin(0, 0);
    int best = 0;
    double bestDistance = points[0].distanceMember(origin);
    for (int i = 1; i < size; ++i) {
        const double distance = points[i].distanceMember(origin);
        if (distance < bestDistance) {
            best = i;
            bestDistance = distance;
        }
    }
    return points[best];
}
int main() {
    Point points[4] = {{3,4}, {0,5}, {1,0}, {-1,0}};
    // TODO: change the comparison above so the last point wins a tie.
    closestToOrigin(points, 4).printPoint();
}
