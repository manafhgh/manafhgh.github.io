#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
int main() {
    // Supplied setup: start with a fresh file on every run.
    std::ofstream out("grades.txt");
    if (!out) { std::cerr << "Cannot create file.\n"; return 1; }
    out << "Amal 85\nLina 92\n";
    out.close();
    // TODO: append Omar 78 using std::ios::app, then close the writer.
    // TODO: read and print all records as "name: grade".
    // TODO: print "Average: " and the average with one decimal place.
}
