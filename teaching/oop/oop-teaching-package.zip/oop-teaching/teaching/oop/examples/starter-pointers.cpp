#include <iostream>
int main() {
    int x = 5, y = 10;
    int* a = &x;
    int* b = &x;
    // TODO: change x to 20 through a, then print the value through b.
    // TODO: point only a at y, then print *a and *b on one line.
    (void)a; (void)b; (void)y;
}
