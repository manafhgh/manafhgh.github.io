#include <iostream>
using namespace std;
class A {
    int x=5;
public:
    A* byPointer() { return this; }
    A byValue() const { return *this; }
    A& byReference() { return *this; }
    void boo() { x += 55; }
    void print() const { cout << x << '\n'; }
};
int main() {
    A a;  // Starts at 5.
    a.byValue().boo();       // Changes a temporary copy.
    a.print();              // 5
    a.byReference().boo();   // Changes a itself.
    a.print();              // 60
    a.byPointer()->boo();    // Changes a again.
    // Alternative to the previous call: (*a.byPointer()).boo();
    a.print();              // 115
}
