#include <iostream>
class Animal {
public:
    Animal() { std::cout << "Base constructor\n"; }
    virtual ~Animal() = default;
    virtual void makeSound() = 0;
};
class Cow : public Animal {
public:
    void makeSound() override {
        std::cout << "Moo!\n";
    }
};
int main() {
    Cow cow;
    Animal* animal = &cow;
    animal->makeSound();
}
