#include <iostream>
int countEven(const int values[], int size) {
    if (size <= 0) return 0;
    return (values[size - 1] % 2 == 0 ? 1 : 0) + countEven(values, size - 1);
}
int main() {
    const int values[5] = {1, 2, 5, 0, 0};
    std::cout << countEven(values, 5) << '\n';
}
