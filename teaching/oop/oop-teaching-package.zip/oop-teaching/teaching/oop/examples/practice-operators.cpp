#include <iostream>
class Point {
    double x, y;
public:
    Point(double xx = 0, double yy = 0) : x(xx), y(yy) {}
    Point operator+() const {
        return *this;
    }
    bool operator==(const Point& other) const { return x == other.x && y == other.y; }
};
int main() {
    Point p(2, 4);
    Point copy = +p;
    std::cout << std::boolalpha << (copy == p) << '\n';
}
