#include <iostream>
class Shape {
public:
    virtual ~Shape() = default;
    virtual void draw() = 0;
};
class Rectangle : public Shape {
public:
    void draw() override { std::cout << "Drawing a rectangle\n"; }
};
class Circle : public Shape {
public:
    void draw() override { std::cout << "Drawing a circle\n"; }
};
int main() {
    Shape* shape_ptr = new Circle();
    // These casts ask which object the base pointer actually refers to.
    Rectangle* rectangle = dynamic_cast<Rectangle*>(shape_ptr);
    if (rectangle) rectangle->draw();
    else std::cout << "Could not cast shape_ptr to a Rectangle\n";
    Circle* circle = dynamic_cast<Circle*>(shape_ptr);
    if (circle) circle->draw();
    else std::cout << "Could not cast shape_ptr to a Circle\n";
    delete shape_ptr;
}
