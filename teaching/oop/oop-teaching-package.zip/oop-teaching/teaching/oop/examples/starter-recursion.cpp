#include <iostream>
long long factorial(int n) {
    // TODO: add a base case and a recursive call. Use n >= 0.
    (void)n;
    return 0; // Replace this placeholder.
}
int main() {
    std::cout << factorial(0) << ' ' << factorial(1) << ' ' << factorial(5) << '\n';
}
