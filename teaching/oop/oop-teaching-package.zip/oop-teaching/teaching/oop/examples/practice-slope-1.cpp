#include <iostream>
#include <string>

using std::cout;
using std::string;

class Point {
private:
    double x, y;

public:
    Point(double x, double y) : x(x), y(y) {}
    double getX() const { return x; }
    double getY() const { return y; }
};

class Line {
    Point start, end;

public:
    Line(const Point& a, const Point& b) : start(a), end(b) {}
    const Point& getStart() const { return start; }
    const Point& getEnd() const { return end; }
};

double slope(const Line& line) {
    const double dx = line.getEnd().getX() - line.getStart().getX();
    if (dx == 0.0)
        throw string("Vertical line: undefined slope");
    return (line.getEnd().getY() - line.getStart().getY()) / dx;
}

void showSlope(const Line& line) {
    try {
        const double result = slope(line);
        cout << result << '\n';
    } catch (const string& message) {
        cout << message << '\n';
    }
}

int main() {
    const Point a(1, 2), b(4, 8), c(4, 2), d(1, 8);
    showSlope(Line(a, b));
    showSlope(Line(a, c));
    showSlope(Line(a, d));
}
