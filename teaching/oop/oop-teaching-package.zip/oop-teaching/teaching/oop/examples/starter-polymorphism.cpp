#include <iostream>
class Animal {
public:
    Animal() { std::cout << "Base constructor\n"; }
    virtual ~Animal() = default;
    virtual void makeSound() = 0;
};
class Cow : public Animal {
public:
    void makeSound() override {
        // TODO: print Moo! followed by a newline.
    }
};
int main() {
    Cow cow;
    Animal* animal = &cow;
    animal->makeSound();
}
