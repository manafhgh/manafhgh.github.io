"""Build the single-file teaching page. Edit page-shell.html for the page header."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent/'teaching/oop'
data={name:json.loads((root/f'{filename}.json').read_text()) for name,filename in [('examples','content'),('topics','topics'),('memory','memory'),('optional','optional'),('model','model'),('downloads','downloads')]}
data['model']['html']=(root/'classes-lesson.html').read_text()
payload=json.dumps(data,ensure_ascii=False).replace('</',r'<\/')
main_count=1+sum(t.get('group')!='revision' for t in data['topics'])
activity_count=2*(len(data['topics'])+len(data['optional']))+7+sum(len(t.get('guide',{}).get('quiz',[])) for t in data['topics'])
stats=f'<span><strong>{main_count}</strong>topics</span><span><strong>{len(data["examples"])}</strong>examples</span><span><strong>{activity_count}</strong>activities</span>'
html=(root/'page-shell.html').read_text()
replacements={'@@CSS@@':(root/'style.css').read_text(),'@@DATA@@':payload,'@@APP@@':'\n'.join((root/n).read_text() for n in ['memory.js','guided.js','app.js','theme.js','counters.js']),'@@STATS@@':stats,'@@MAX@@':str(len(data['topics']))}
for key,value in replacements.items():html=html.replace(key,value)
(root/'index.html').write_text(html)
print(root/'index.html')
