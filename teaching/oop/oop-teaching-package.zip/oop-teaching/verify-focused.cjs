const fs=require('fs'),vm=require('vm'),assert=require('assert');
const {parseHTML}=require('linkedom');
const root=__dirname+'/teaching/oop/';
const {document,window}=parseHTML(fs.readFileSync(root+'index.html','utf8'));window.location={hash:'#revision'};
const memory=new Map();const ctx={document,window,localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,String(v))},console,setTimeout,clearTimeout,AbortController,Blob,URL,Event:window.Event,navigator:{},confirm:()=>true};
vm.createContext(ctx);[...document.querySelectorAll('script')].forEach(s=>vm.runInContext(s.textContent,ctx));
const data=window.OOP_DATA,$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const route=hash=>{window.location.hash=hash;window.dispatchEvent(new window.Event('hashchange'));};
const event=(el,type)=>el.dispatchEvent(new window.Event(type,{bubbles:true,cancelable:true}));
assert.equal($$('.topic').filter(x=>!x.hidden).length,0);
assert(!$('#revision-overview').hidden);
assert(!document.body.textContent.includes('Read it. Predict it. Run it. Build on it.'));
assert($('.study-note').textContent.includes('not intended to serve as a complete reference'));
for(const t of data.topics){
 route('#'+t.id);assert.deepEqual($$('.topic').filter(x=>!x.hidden).map(x=>x.id),[t.id]);
 assert.equal($('#topic-nav a[aria-current=page]').getAttribute('href'),'#'+t.id);
 if(t.guide){
  assert.equal(t.guide.quiz.length,3);const form=$(`#${t.id} .guide-quiz`);
  t.guide.quiz.forEach((q,n)=>{const radio=form.querySelector(`input[name="${t.id}-q${n}"][value="${q.correct}"]`);radio.setAttribute('checked','');radio.checked=true;event(radio,'change');});
  event(form,'submit');assert(form.querySelector('.guide-result').textContent.includes('3/3 correct'));
  assert.equal(memory.get('oop-v1-quiz-passed-'+t.id),'yes');
 }
}
assert.equal($$('.guide-quiz').length,24);assert.equal($$('.quiz-question').length,81);
const extraQuiz=$('#friends-practice .extra-quiz');
const extras=data.topics.find(t=>t.id==='friends').extraPractice;
extras.quiz.forEach((q,n)=>{const radio=extraQuiz.querySelector(`[data-guide-question="${n}"] input[value="${q.correct}"]`);radio.setAttribute('checked','');radio.checked=true;event(radio,'change');});
event(extraQuiz,'submit');
assert(extraQuiz.querySelector('.guide-result').textContent.includes('4/4 correct'));
assert(extraQuiz.querySelector('[data-guide-question="1"] .quiz-feedback').textContent.includes('does not need the function body'));
for(const id of ['composition','friends']){
 const t=data.topics.find(t=>t.id===id), section=$('#'+id+'-practice');
 assert(section.textContent.includes('Coding practice (Part 1)'));
 assert(section.textContent.includes('Coding practice (Part 2)'));
 for(const ex of t.extraPractice.items){
   const starter=section.querySelector(`[data-id="workspace-${ex.id}"]`);
   const solution=section.querySelector(`[data-id="${ex.id}"]`);
   assert.equal(starter.querySelector('.code-view').textContent,ex.starter);
   assert.equal(solution.querySelector('.code-view').textContent,ex.solution);
   solution.querySelector('[data-action=reset]').click();
   assert.equal(solution.querySelector('.editor').value,ex.solution);
 }
}
route('#classes-trace');assert(!$('#classes').hidden);assert($('#lifetime').hidden);
route('#linked');assert(!$('#dynamic').hidden);assert($('#linked').open);
route('#all');assert.equal($$('.topic').filter(x=>!x.hidden).length,25);
route('#functions');$('#search').value='temperature difference';event($('#search'),'input');assert(!$('#functions').hidden,'Search must preserve the selected lesson');assert(!$('#topic-nav a[data-topic=temperature]').hidden);
$('#search').value='';event($('#search'),'input');
const workspace=$('[data-id="workspace-functions"]');ctx.container=workspace;
workspace.querySelector('.editor').value=data.topics[0].exercise.solution;
ctx.fetch=async(url,opts)=>{const p=JSON.parse(opts.body);assert.equal(p.source,workspace.querySelector('.editor').value);assert.equal(p.options.executeParameters.stdin,data.topics[0].exercise.stdin);return {ok:true,json:async()=>({code:0,didExecute:true,stdout:[{text:'7'}],buildResult:{code:0,stderr:[]}})}};
(async()=>{
 await vm.runInContext('runProgram(container,"sample")',ctx);assert.equal(memory.get('oop-v1-sample-passed-functions'),'yes');assert(workspace.querySelector('.status').textContent.includes('Sample output matches'));
 ctx.fetch=async()=>({ok:true,json:async()=>({code:0,didExecute:true,stdout:[{text:'5'}],buildResult:{code:0,stderr:[]}})});
 await vm.runInContext('runProgram(container,"sample")',ctx);assert.equal(memory.get('oop-v1-sample-passed-functions'),'');assert(workspace.querySelector('.output').textContent.includes('Expected sample output'));
 route('#recursion');route('#functions');assert.equal(workspace.querySelector('.editor').value,data.topics[0].exercise.solution,'Navigation must preserve editor state');
 const points=data.examples.filter(e=>e.code.includes('class Point'));
 assert(points.every(e=>!e.code.match(/\b(?:int|float)\s+x\s*[,;]/)));
 assert(data.examples.find(e=>e.id==='point-basics').output.includes('(2.5,3.5)'));
 console.log('PASS: all 25 focused routes, nested anchors, optional exercise, view-all, 72 new question answers, note/removal, search, sample-output success/failure, retained edits, and double Point coordinates.');
})().catch(e=>{console.error(e);process.exitCode=1});
