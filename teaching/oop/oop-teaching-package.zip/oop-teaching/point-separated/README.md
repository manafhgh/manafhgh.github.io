# Point project: compile and run in the VS Code terminal

This folder contains the instructor's three-file Point example, adapted to use
double coordinates, const read-only functions, and the cached closest-point search.
The unused static counter and inactive commented experiments were removed. The
copy-constructor and address demonstration are retained. No input is required.

## What each file does

- point.h is the header: it declares Point and its public member functions.
- point.cpp is a source file: it defines those member functions.
- driver.cpp is a source file: it contains main and the non-member search functions.

The include guard in point.h prevents repeated inclusion in one translation unit.
Both source files include the header. Do not include point.cpp from driver.cpp.

## Open the correct folder

1. Extract the ZIP; do not try to compile inside the compressed folder.
2. In VS Code choose File > Open Folder and open point-separated, containing
   point.h, point.cpp and driver.cpp directly.
3. Save your changes, then choose Terminal > New Terminal.
4. Confirm the terminal is in that folder. `ls` (macOS/Linux/PowerShell) or `dir`
   (Windows Command Prompt) should list the three files.
5. Check `g++ --version`. A C++ compiler must be installed separately; VS Code and
   its C++ extension do not themselves supply one. If clang++ is your compiler,
   use the macOS/Linux alternative below. For MSVC, see the separate note below.

## macOS or Linux with GCC

Compile BOTH source files in one command:

    g++ -std=c++17 -Wall -Wextra -pedantic driver.cpp point.cpp -o point_demo

After compilation succeeds, run:

    ./point_demo

On macOS, g++ may invoke Apple Clang. An explicit Clang alternative is:

    clang++ -std=c++17 -Wall -Wextra -pedantic driver.cpp point.cpp -o point_demo
    ./point_demo

## Windows with GCC such as MinGW-w64

In PowerShell or Command Prompt, compile:

    g++ -std=c++17 -Wall -Wextra -pedantic driver.cpp point.cpp -o point_demo.exe

Then run:

    .\point_demo.exe

For Microsoft Visual C++ instead of GCC, use a VS Code terminal configured from
its Developer Command Prompt, then:

    cl /std:c++17 /EHsc /W4 driver.cpp point.cpp /Fe:point_demo.exe
    .\point_demo.exe

Use only the commands for the compiler installed on your computer.

## What the options mean

- -std=c++17 selects the C++17 standard.
- -Wall enables many common compiler warnings.
- -Wextra enables additional warnings.
- -pedantic requests diagnostics for some non-standard language extensions.
- -o sets the executable filename.

The warning options are useful but optional. The header is found through
#include "point.h"; it is not another source file to compile in this command.

## What you should see

The program first prints (1,2) and (0,0). It then selects (1,0) from the array,
prints a copy-constructor message, shows addresses, and prints the closest point.
The selected element's address matches points[2]; the returned object's address
is different because it is a separate object. Actual addresses change between
runs. The search requires a nonempty array and keeps the first point on a tie.

## If the Run button does not work

A Run button or extension may compile only the currently open .cpp file. That can
produce undefined-reference or unresolved-external errors because point.cpp was
not linked. The commands above explicitly compile both sources; they do not
require tasks.json. Build/debug buttons can use a configured tasks.json, while
an extension's Run Code button may use its own settings.

- Compiler not found: check compiler installation and PATH, then restart the terminal.
- Source file not found: check the current folder and exact filenames/capitalization.
- Undefined reference/unresolved external: include both driver.cpp and point.cpp.
- Multiple definitions: do not #include a .cpp file or compile the same definitions twice.
- Executable not found: first fix compiler errors; run only after the build succeeds.
- After editing: save, compile again, then run the newly built executable.

Official setup help: https://code.visualstudio.com/docs/languages/cpp
The web page combines the files for its online runner. This download contains the
real separate files for local compilation.
