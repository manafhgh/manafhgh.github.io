#ifndef POINT_H
#define POINT_H

class Point {
private:
    double x;
    double y;
public:
    // With no arguments, construct the origin (0,0).
    Point(double xx = 0, double yy = 0);
    Point(const Point& other);
    ~Point();

    void setX(double value);
    void setY(double value);
    double getX() const;
    double getY() const;
    void printPoint() const;
    int whichQuadrant() const;
    double distanceMember(const Point& other) const;
};

#endif
