#include <cmath>
#include <iostream>
#include "point.h"

// The non-member version reads both points through their public interface.
double distance(const Point& a, const Point& b) {
    const double dx = b.getX() - a.getX();
    const double dy = b.getY() - a.getY();
    return std::sqrt(dx * dx + dy * dy);
}

Point closestToOrigin(const Point points[], int size) {
    // Precondition: size > 0 and points contains at least size elements.
    const Point origin(0, 0);
    int best = 0;
    double bestDistance = points[0].distanceMember(origin);
    for (int i = 1; i < size; ++i) {
        const double distance = points[i].distanceMember(origin);
        if (distance < bestDistance) {
            best = i;
            bestDistance = distance;
        }
    }
    std::cout << "Address of selected array element: " << &points[best] << '\n';
    return points[best]; // A value, not a reference to an array element.
}

int main() {
    Point p1(1, 2), p2;
    p1.printPoint();
    p2.printPoint();

    Point points[5] = {{3,5}, {5,3}, {1,0}, {6,6}, {7,8}};
    points[4].setX(20);
    Point closest = closestToOrigin(points, 5);
    std::cout << "Address of returned object: " << &closest << '\n';
    std::cout << "Address of points[2]: " << &points[2] << '\n';
    std::cout << "Closest point: ";
    closest.printPoint();
}
