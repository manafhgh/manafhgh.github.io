#include <cmath>
#include <iostream>
#include "point.h"

Point::Point(double xx, double yy) : x(xx), y(yy) {}

Point::Point(const Point& other) : x(other.x), y(other.y) {
    std::cout << "Copy constructor: ";
    printPoint();
}

Point::~Point() = default;
void Point::setX(double value) { x = value; }
void Point::setY(double value) { y = value; }
double Point::getX() const { return x; }
double Point::getY() const { return y; }
void Point::printPoint() const { std::cout << '(' << x << ',' << y << ")\n"; }

int Point::whichQuadrant() const {
    if (x > 0 && y > 0) return 1;
    if (x < 0 && y > 0) return 2;
    if (x < 0 && y < 0) return 3;
    if (x > 0 && y < 0) return 4;
    return -1; // A point on either axis, including the origin, has no quadrant.
}

double Point::distanceMember(const Point& other) const {
    const double dx = other.x - x;
    const double dy = other.y - y;
    return std::sqrt(dx * dx + dy * dy);
}
