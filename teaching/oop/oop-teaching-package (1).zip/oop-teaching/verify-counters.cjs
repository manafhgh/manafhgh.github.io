// Counter routing tests use a fake transport; they never send real analytics hits.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const {parseHTML}=require('linkedom');
const html=fs.readFileSync(__dirname+'/teaching/oop/index.html','utf8');
function boot(hash='',published=true,failing=false) {
 const {document,window}=parseHTML(html), hits=[], requests=[];
 window.location={hash,protocol:published?'https:':'http:',hostname:published?'manafhgh.com':'localhost'};
 const memory=new Map();
 const ctx={document,window,localStorage:{getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,String(v))},console,setTimeout,clearTimeout,AbortController,Blob,URL,Event:window.Event,navigator:{},confirm:()=>true,
 fetch:async url=>{requests.push(url);return {ok:!failing,status:failing==='missing'?404:failing?403:200,json:async()=>({count:failing==='missing'?'0':url.includes('topics')?'42':'1,234'})};}};
 vm.createContext(ctx);
 // Snapshot scripts before running: counter setup adds an external script.
 const scripts=[...document.querySelectorAll('script')];
 scripts.forEach(s=>vm.runInContext(s.textContent,ctx));
 const loader=document.querySelector('script[data-goatcounter]');
 if(loader){assert(window.goatcounter.no_onload);window.goatcounter.count=item=>hits.push(item);loader.onload();}
 function route(id){window.location.hash='#'+id;window.dispatchEvent(new window.Event('hashchange'));}
 return {document,window,hits,requests,route};
}
const settle=()=>new Promise(resolve=>setTimeout(resolve,0));
(async()=>{
 const a=boot();assert.equal(a.hits.length,1);assert.equal(a.hits[0].path,'/teaching/oop/total');
 await settle();assert.equal(a.document.getElementById('visit-counter').textContent,'1,234');
 a.route('classes');assert.equal(a.hits.length,3);assert.equal(a.hits[2].path,'/teaching/oop/topics/classes');await settle();assert.equal(a.document.getElementById('visit-counter').textContent,'42');
 a.route('classes-learn');a.route('main');assert.equal(a.hits.length,3,'Subsections and skip links are not new views');
 a.route('inheritance');a.route('classes');assert.equal(a.hits.length,7,'Returning to a topic counts again');
 a.route('revision');assert.equal(a.hits.length,8);a.route('all');assert.equal(a.hits.length,9,'All lessons is one view, not 25');
 assert(a.hits.every(x=>x.no_session===true && x.event===false));
 await settle();assert.equal(a.document.getElementById('visit-counter').textContent,'1,234','No stale topic count after navigating away');
 const direct=boot('#pointers');assert.equal(direct.hits.length,2,'Direct topic entry counts overall once and topic once');
 const reload=boot('#pointers');assert.equal(reload.hits.length,2,'A reload is counted again');
 const local=boot('#classes',false);assert.equal(local.hits.length,0);assert.equal(local.requests.length,0);
 const unavailable=boot('',true,true);await settle();assert(unavailable.document.getElementById('visit-counter').hidden);assert(unavailable.document.querySelector('#revision-overview'));
 assert(a.requests.every(x=>x.startsWith('https://manafhgh.goatcounter.com/counter/')));
 const missing=boot('',true,'missing');await settle();assert.equal(missing.document.getElementById('visit-counter').textContent,'0');assert(!missing.document.getElementById('visit-counter').hidden,'A real zero from a 404 JSON response is displayed');
 console.log('PASS: overall/topic totals, repeats, direct links, reloads, subsection deduplication, all view, local exclusions, delayed responses, and unavailable counters.');
})().catch(e=>{console.error(e);process.exitCode=1});
