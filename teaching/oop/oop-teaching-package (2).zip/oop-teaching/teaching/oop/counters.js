// Shared counters. Only the published course sends hits; previews never do.
(function () {
    const host = 'https://manafhgh.goatcounter.com';
    const totalPath = '/teaching/oop/total';
    const topicPrefix = '/teaching/oop/topics/';
    const published = window.location.protocol === 'https:' &&
        ['manafhgh.com', 'www.manafhgh.com'].includes(window.location.hostname);
    const counter = document.getElementById('visit-counter');
    const topics = new Map(DATA.topics.map(t => [t.id, t.title]));
    const cache = new Map(), pending = new Map();
    let previous = null, selectedPath = totalPath, ready = false, failed = false;
    let queue = [];

    // These options are passed on EVERY hit: repeat reloads and returns count.
    function hit(path, title) {
        const item = {path, title, no_session: true, event: false, referrer: ''};
        if (ready) { try { window.goatcounter.count(item); } catch (_) {} }
        else if (!failed && queue.length < 100) queue.push(item);
    }
    function readCount(path) {
        const cached = cache.get(path);
        if (cached && Date.now() - cached.at < 300000) return Promise.resolve(cached.value);
        if (pending.has(path)) return pending.get(path);
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        const request = fetch(host + '/counter/' + encodeURIComponent(path) + '.json?start=2000-01-01', {
            signal: controller.signal, credentials: 'omit', referrerPolicy: 'no-referrer'
        }).then(response => {
            // A new path returns HTTP 404 with a valid zero-count JSON body.
            // Do not hide that zero; cached missing-path responses may persist.
            if (!response.ok && response.status !== 404) throw new Error('Counter unavailable');
            return response.json().then(data => {
                if (!response.ok && String(data.count) !== '0') throw new Error('Counter unavailable');
                return data;
            });
        }).then(data => {
            // GoatCounter supplies a formatted string. Never insert server HTML.
            const value = String(data.count ?? '');
            if (!/^\d[\d\s,._\u00a0\u202f]*$/.test(value) || value.length > 40)
                throw new Error('Invalid counter');
            cache.set(path, {value, at: Date.now()}); return value;
        }).finally(() => { clearTimeout(timeout); pending.delete(path); });
        pending.set(path, request); return request;
    }
    function show(path, title) {
        selectedPath = path;
        counter.hidden = true;
        counter.textContent = '';
        if (!published) return;
        readCount(path).then(value => {
            if (selectedPath !== path) return;
            counter.textContent = value;
            counter.setAttribute('aria-label', title + ': ' + value);
            counter.hidden = false;
        }).catch(() => { /* Missing/disabled/blocked counters never affect lessons. */ });
    }
    function view(id) {
        const topic = topics.has(id);
        if (id !== previous && published) {
            hit(totalPath, 'OOP · Overall visits');
            if (topic) hit(topicPrefix + id, 'OOP · ' + topics.get(id));
        }
        previous = id;
        show(topic ? topicPrefix + id : totalPath,
            topic ? 'Visits to ' + topics.get(id) : 'Overall OOP visits');
    }
    window.oopVisitCounter = {view};
    if (published) {
        // No automatic pageview: it would duplicate the initial routed view.
        window.goatcounter = {no_onload: true, no_events: true, endpoint: host + '/count'};
        const script = document.createElement('script');
        script.src = 'https://gc.zgo.at/count.js';
        script.async = true;
        script.setAttribute('data-goatcounter', host + '/count');
        script.onload = function () {
            ready = typeof window.goatcounter.count === 'function';
            failed = !ready;
            const waiting = queue; queue = [];
            if (ready) waiting.forEach(item => { try { window.goatcounter.count(item); } catch (_) {} });
        };
        script.onerror = function () { failed = true; queue = []; };
        document.head.appendChild(script);
    }
    // Navigation was initialized before this file; record its resolved first view.
    view(currentLessonId);
})();
